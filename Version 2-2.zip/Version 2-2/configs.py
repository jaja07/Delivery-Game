# -*- coding: utf-8 -*-
"""
Configurations d'entraînement
=============================
Exemples de différentes configurations pour expérimenter.

Author : yasmi
"""

# Configuration 1: RAPIDE (10 min)
# Idéal pour tester rapidement
CONFIG_FAST = {
    "name": "Fast Training (10 min)",
    "env": {
        "grid_size": 8,
        "episode_length": 80,
        "num_obstacles": 3
    },
    "training": {
        "num_episodes": 200,
        "learning_rate": 1e-3,
        "gamma": 0.99,
        "eval_interval": 50
    }
}

# Configuration 2: NORMAL (30 min)
# Configuration par défaut du projet
CONFIG_NORMAL = {
    "name": "Normal Training (30 min)",
    "env": {
        "grid_size": 10,
        "episode_length": 150,
        "num_obstacles": 8
    },
    "training": {
        "num_episodes": 500,
        "learning_rate": 1e-3,
        "gamma": 0.99,
        "eval_interval": 50
    }
}

# Configuration 3: COMPLET (1 heure)
# Entraînement plus long pour meilleure performance
CONFIG_COMPLETE = {
    "name": "Complete Training (1 hour)",
    "env": {
        "grid_size": 10,
        "episode_length": 200,
        "num_obstacles": 10
    },
    "training": {
        "num_episodes": 1000,
        "learning_rate": 5e-4,
        "gamma": 0.99,
        "eval_interval": 100
    }
}

# Configuration 4: DIFFICILE
# Grille complexe avec beaucoup d'obstacles
CONFIG_HARD = {
    "name": "Hard Configuration",
    "env": {
        "grid_size": 15,
        "episode_length": 250,
        "num_obstacles": 20
    },
    "training": {
        "num_episodes": 2000,
        "learning_rate": 1e-3,
        "gamma": 0.99,
        "eval_interval": 100
    }
}

# Configuration 5: LEARNING RATE ÉLEVÉ
# Test avec learning rate plus élevé
CONFIG_HIGH_LR = {
    "name": "High Learning Rate",
    "env": {
        "grid_size": 10,
        "episode_length": 150,
        "num_obstacles": 8
    },
    "training": {
        "num_episodes": 500,
        "learning_rate": 5e-3,  # Plus élevé
        "gamma": 0.99,
        "eval_interval": 50
    }
}

# Configuration 6: LEARNING RATE BAS
# Test avec learning rate bas (plus stable)
CONFIG_LOW_LR = {
    "name": "Low Learning Rate",
    "env": {
        "grid_size": 10,
        "episode_length": 150,
        "num_obstacles": 8
    },
    "training": {
        "num_episodes": 500,
        "learning_rate": 5e-4,  # Plus bas
        "gamma": 0.99,
        "eval_interval": 50
    }
}

# Configuration 7: GAMMA BAS
# Plus d'importance au court terme
CONFIG_GAMMA_LOW = {
    "name": "Low Gamma (Short-term)",
    "env": {
        "grid_size": 10,
        "episode_length": 150,
        "num_obstacles": 8
    },
    "training": {
        "num_episodes": 500,
        "learning_rate": 1e-3,
        "gamma": 0.9,  # Plus bas = court terme
        "eval_interval": 50
    }
}

# Configuration 8: GAMMA ÉLEVÉ
# Plus d'importance au long terme
CONFIG_GAMMA_HIGH = {
    "name": "High Gamma (Long-term)",
    "env": {
        "grid_size": 10,
        "episode_length": 150,
        "num_obstacles": 8
    },
    "training": {
        "num_episodes": 500,
        "learning_rate": 1e-3,
        "gamma": 0.999,  # Très élevé = long terme
        "eval_interval": 50
    }
}

# Configurations de test
ALL_CONFIGS = {
    "fast": CONFIG_FAST,
    "normal": CONFIG_NORMAL,
    "complete": CONFIG_COMPLETE,
    "hard": CONFIG_HARD,
    "high_lr": CONFIG_HIGH_LR,
    "low_lr": CONFIG_LOW_LR,
    "gamma_low": CONFIG_GAMMA_LOW,
    "gamma_high": CONFIG_GAMMA_HIGH
}


def get_config(name="normal"):
    """
    Récupère une configuration par nom.

    Args:
        name: Nom de la configuration

    Returns:
        config: Dictionnaire de configuration
    """
    if name in ALL_CONFIGS:
        return ALL_CONFIGS[name]
    else:
        print(f"Configuration '{name}' non trouvée. Configurations disponibles:")
        for config_name in ALL_CONFIGS.keys():
            config = ALL_CONFIGS[config_name]
            print(f"  - {config_name}: {config['name']}")
        return ALL_CONFIGS["normal"]


def train_with_config(config_name="normal"):
    """
    Entraîne un agent avec une configuration spécifique.

    Args:
        config_name: Nom de la configuration
    """
    from game_env import DeliveryGameEnv
    from train_agent import REINFORCEAgent
    from datetime import datetime
    from pathlib import Path

    config = get_config(config_name)

    print("\n" + "=" * 70)
    print(f"ENTRAÎNEMENT: {config['name']}")
    print("=" * 70)

    print("\n🎮 Création de l'environnement...")
    env = DeliveryGameEnv(**config['env'])
    print(f"  Grille: {config['env']['grid_size']}×{config['env']['grid_size']}")
    print(f"  Obstacles: {config['env']['num_obstacles']}")
    print(f"  Longueur max: {config['env']['episode_length']} steps")

    print("\n Création de l'agent...")
    agent = REINFORCEAgent(
        state_size=env.state_size,
        action_size=env.action_size,
        learning_rate=config['training']['learning_rate'],
        gamma=config['training']['gamma']
    )
    print(f"  Learning rate: {config['training']['learning_rate']}")
    print(f"  Gamma: {config['training']['gamma']}")

    print("\n Entraînement...")
    agent.train(
        env,
        num_episodes=config['training']['num_episodes'],
        eval_interval=config['training']['eval_interval']
    )

    print("\n Évaluation finale...")
    stats = agent.evaluate(env, num_episodes=100)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    Path("models").mkdir(exist_ok=True)
    Path("results").mkdir(exist_ok=True)
    model_path = f"models/{config_name}_agent_{timestamp}.pt"
    stats_path = f"results/{config_name}_stats_{timestamp}.json"

    agent.save_model(model_path)
    agent.save_training_stats(stats_path)

    print(f"\n Entraînement terminé !")
    print(f"  Modèle: {model_path}")
    print(f"  Stats: {stats_path}")
    print(f"  Reward final: {stats['mean_reward']:.2f}")
    print(f"  Success rate: {stats['success_rate']:.1f}%")

    return agent, stats


def compare_configs():
    """
    Compare différentes configurations.
    Entraîne plusieurs agents avec différentes configs et les évalue.
    """
    from game_env import DeliveryGameEnv
    from train_agent import REINFORCEAgent
    import json
    from pathlib import Path

    results = {}

    # Configurations à tester
    configs_to_test = ["fast", "high_lr", "low_lr"]

    print("\n" + "=" * 70)
    print("COMPARAISON DE CONFIGURATIONS")
    print("=" * 70)

    for config_name in configs_to_test:
        print(f"\n▼ Entraînement avec {config_name}...")

        config = get_config(config_name)

        env = DeliveryGameEnv(**config['env'])
        agent = REINFORCEAgent(
            state_size=env.state_size,
            action_size=env.action_size,
            learning_rate=config['training']['learning_rate'],
            gamma=config['training']['gamma']
        )

        agent.train(env, num_episodes=config['training']['num_episodes'])
        stats = agent.evaluate(env, num_episodes=50)

        results[config_name] = {
            "config": config['name'],
            "reward": stats['mean_reward'],
            "success_rate": stats['success_rate'],
            "length": stats['mean_length']
        }

        print(f"  ✓ Reward: {stats['mean_reward']:.2f}")
        print(f"  ✓ Success: {stats['success_rate']:.1f}%")

    print("\n" + "=" * 70)
    print("RÉSULTATS COMPARATIFS")
    print("=" * 70 + "\n")

    for config_name, result in results.items():
        print(f"{result['config']}:")
        print(f"  Reward:        {result['reward']:6.2f}")
        print(f"  Success rate:  {result['success_rate']:6.1f}%")
        print(f"  Avg length:    {result['length']:6.1f} steps")
        print()

    Path("results").mkdir(exist_ok=True)
    with open("results/config_comparison.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    print("✓ Résultats sauvegardés: results/config_comparison.json")


if __name__ == "__main__":
    import sys

    print("\nCONFIGURATIONS D'ENTRAÎNEMENT")
    print("-" * 70)
    print("\nUsage:")
    print("  python configs.py <config_name>")
    print("  python configs.py compare")
    print("\nConfigurations disponibles:")

    for name, config in ALL_CONFIGS.items():
        print(f"  - {name}: {config['name']}")

    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()

        if arg == "compare":
            compare_configs()
        elif arg in ALL_CONFIGS:
            train_with_config(arg)
        else:
            print(f"\n Configuration inconnue: {arg}")
    else:
        print("\n Exemple: python configs.py fast")