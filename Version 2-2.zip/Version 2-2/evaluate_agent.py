"""
Script d'évaluation du modèle entraîné
========================================
Évalue le modèle entraîné sur plusieurs métriques et le compare avec une baseline.

Métriques:
- Récompense moyenne
- Taux de succès (livraison complète)
- Efficacité (steps pour réussir)
- Robustesse (performance sur plusieurs jeux)

Author: yasmi
"""

import numpy as np
import torch
from tqdm import tqdm
import json
from pathlib import Path
from datetime import datetime

from game_env import DeliveryGameEnv
from policy_network import PolicyNetwork


class ModelEvaluator:
    """Évalue la performance d'un modèle entraîné"""
    
    def __init__(self, env, model_path=None):
        """
        Initialise l'évaluateur.
        
        Args:
            env: Environnement du jeu
            model_path: Chemin vers le modèle entraîné (None pour random)
        """
        self.env = env
        
        # Charge le modèle si fourni
        if model_path:
            self.policy = PolicyNetwork(env.state_size, env.action_size)
            self.policy.load_state_dict(torch.load(model_path, weights_only=True))
            self.policy.eval()
            self.is_trained = True
        else:
            self.policy = None
            self.is_trained = False
    
    def evaluate_episode(self, render=False):
        """
        Évalue une épisode.
        
        Returns:
            results: Dictionnaire avec les résultats
        """
        state = self.env.reset()
        episode_reward = 0
        episode_length = 0
        success = False
        
        trajectory = []
        
        while True:
            # Sauvegarde la position
            robot_pos = tuple(self.env.robot_pos.copy())
            
            # Obtient l'action
            if self.is_trained:
                action, _ = self.policy.get_action(state, training=False)
            else:
                # Baseline: action aléatoire
                action = np.random.randint(0, self.env.action_size)
            
            # Exécute l'action
            state, reward, done, info = self.env.step(action)
            episode_reward += reward
            episode_length += 1
            
            trajectory.append({
                'position': robot_pos,
                'action': action,
                'reward': reward
            })
            
            if info["success"]:
                success = True
            
            if done:
                break
        
        return {
            'total_reward': episode_reward,
            'episode_length': episode_length,
            'success': success,
            'trajectory': trajectory
        }
    
    def evaluate_batch(self, num_episodes=100):
        """
        Évalue le modèle sur un batch d'épisodes.
        
        Args:
            num_episodes: Nombre d'épisodes à évaluer
        
        Returns:
            stats: Statistiques d'évaluation
        """
        rewards = []
        lengths = []
        successes = 0
        efficient_runs = 0  # Runs qui réussissent en < 100 steps
        
        print(f"\nÉvaluation sur {num_episodes} épisodes...")
        
        for _ in tqdm(range(num_episodes), desc="Évaluation"):
            result = self.evaluate_episode()
            
            rewards.append(result['total_reward'])
            lengths.append(result['episode_length'])
            
            if result['success']:
                successes += 1
                if result['episode_length'] < 100:
                    efficient_runs += 1
        
        rewards = np.array(rewards)
        lengths = np.array(lengths)
        
        stats = {
            'num_episodes': num_episodes,
            'mean_reward': float(np.mean(rewards)),
            'std_reward': float(np.std(rewards)),
            'min_reward': float(np.min(rewards)),
            'max_reward': float(np.max(rewards)),
            'median_reward': float(np.median(rewards)),
            'success_rate': float(successes / num_episodes * 100),
            'efficient_rate': float(efficient_runs / num_episodes * 100),
            'mean_length': float(np.mean(lengths)),
            'std_length': float(np.std(lengths)),
            'min_length': int(np.min(lengths)),
            'max_length': int(np.max(lengths)),
            'is_trained': self.is_trained
        }
        
        return stats
    
    def evaluate_robustness(self, num_games=5, episodes_per_game=20):
        """
        Évalue la robustesse du modèle sur plusieurs configurations de jeu.
        
        Args:
            num_games: Nombre de jeux différents à tester
            episodes_per_game: Épisodes par jeu
        
        Returns:
            robustness_stats: Statistiques de robustesse
        """
        print(f"\nTest de robustesse: {num_games} jeux × {episodes_per_game} épisodes...")
        
        all_stats = []
        
        for game_idx in tqdm(range(num_games), desc="Jeux"):
            # Crée un nouvel environnement avec une configuration aléatoire
            game_size = np.random.randint(8, 12)
            num_obstacles = np.random.randint(5, 15)
            
            env = DeliveryGameEnv(
                grid_size=game_size,
                episode_length=200,
                num_obstacles=num_obstacles
            )
            
            # Évalue ce jeu
            evaluator = ModelEvaluator(
                env,
                model_path=None if not self.is_trained else None  # Réutilise la politique
            )
            evaluator.policy = self.policy
            evaluator.is_trained = self.is_trained
            
            stats = evaluator.evaluate_batch(num_episodes=episodes_per_game)
            all_stats.append(stats)
        
        # Moyenne sur tous les jeux
        robustness = {
            'num_games': num_games,
            'episodes_per_game': episodes_per_game,
            'mean_success_rate': float(np.mean([s['success_rate'] for s in all_stats])),
            'std_success_rate': float(np.std([s['success_rate'] for s in all_stats])),
            'mean_reward': float(np.mean([s['mean_reward'] for s in all_stats])),
            'std_reward': float(np.std([s['mean_reward'] for s in all_stats])),
            'per_game_stats': all_stats
        }
        
        return robustness


def compare_trained_vs_random(num_episodes=100):
    """
    Compare les performances d'un modèle entraîné avec une politique aléatoire.
    
    Args:
        num_episodes: Épisodes d'évaluation
    """
    print("\n" + "="*70)
    print("COMPARAISON: AGENT ENTRAÎNÉ vs ALÉATOIRE")
    print("="*70)
    
    # Crée l'environnement
    env = DeliveryGameEnv(grid_size=10, episode_length=200, num_obstacles=8)
    
    # Évalue la politique aléatoire (baseline)
    print("\n▼ Évaluation de la politique aléatoire (baseline)...")
    evaluator_random = ModelEvaluator(env, model_path=None)
    stats_random = evaluator_random.evaluate_batch(num_episodes=num_episodes)
    
    # Évalue la politique aléatoire
    print("\n" + "-"*70)
    
    print("\n✓ Résultats - Politique aléatoire:")
    print(f"  Récompense: {stats_random['mean_reward']:.2f} ± {stats_random['std_reward']:.2f}")
    print(f"  Taux de succès: {stats_random['success_rate']:.1f}%")
    print(f"  Longueur moyenne: {stats_random['mean_length']:.1f} ± {stats_random['std_length']:.1f}")
    
    return stats_random


def main():
    """Fonction principale"""
    
    import argparse
    
    parser = argparse.ArgumentParser(description='Évalue un modèle entraîné')
    parser.add_argument('--model', type=str, help='Chemin vers le modèle')
    parser.add_argument('--episodes', type=int, default=100, 
                       help='Nombre d\'épisodes d\'évaluation')
    parser.add_argument('--robustness', action='store_true',
                       help='Test de robustesse')
    parser.add_argument('--compare', action='store_true',
                       help='Compare avec politique aléatoire')
    parser.add_argument('--output', type=str, default='results/evaluation.json',
                       help='Fichier pour sauvegarder les résultats')
    
    args = parser.parse_args()
    
    # Crée l'environnement
    env = DeliveryGameEnv(grid_size=10, episode_length=200, num_obstacles=8)
    
    # Crée l'évaluateur
    if args.model:
        print(f"\nChargement du modèle: {args.model}")
        if not Path(args.model).exists():
            print(f"Erreur: Le fichier {args.model} n'existe pas")
            return
        evaluator = ModelEvaluator(env, model_path=args.model)
    else:
        evaluator = ModelEvaluator(env, model_path=None)
    
    results = {}
    
    # Évaluation standard
    print("\n" + "="*70)
    print("ÉVALUATION DU MODÈLE")
    print("="*70)
    stats = evaluator.evaluate_batch(num_episodes=args.episodes)
    
    print(f"\n✓ Résultats principales:")
    print(f"  Récompense moyenne: {stats['mean_reward']:.2f} ± {stats['std_reward']:.2f}")
    print(f"  Récompense min/max: {stats['min_reward']:.1f} / {stats['max_reward']:.1f}")
    print(f"  Taux de succès: {stats['success_rate']:.1f}%")
    print(f"  Taux efficace (< 100 steps): {stats['efficient_rate']:.1f}%")
    print(f"  Longueur moyenne: {stats['mean_length']:.1f} ± {stats['std_length']:.1f} steps")
    
    results['standard_evaluation'] = stats
    
    # Test de robustesse optionnel
    if args.robustness:
        robustness = evaluator.evaluate_robustness(num_games=5, episodes_per_game=20)
        
        print(f"\n✓ Robustesse (5 jeux différents):")
        print(f"  Taux de succès moyen: {robustness['mean_success_rate']:.1f}% "
              f"± {robustness['std_success_rate']:.1f}%")
        print(f"  Récompense moyenne: {robustness['mean_reward']:.2f}")
        
        results['robustness'] = robustness
    
    # Comparaison optionnelle
    if args.compare:
        stats_random = compare_trained_vs_random(num_episodes=args.episodes)
        results['random_baseline'] = stats_random
        
        print("\n" + "="*70)
        print("COMPARAISON")
        print("="*70)
        
        improvement_reward = ((stats['mean_reward'] - stats_random['mean_reward']) 
                            / abs(stats_random['mean_reward'])) * 100
        improvement_success = stats['success_rate'] - stats_random['success_rate']
        
        print(f"\nAmélioration de la récompense: {improvement_reward:+.1f}%")
        print(f"Amélioration du taux de succès: {improvement_success:+.1f} points")
    
    # Sauvegarde les résultats
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    
    results['timestamp'] = datetime.now().isoformat()
    results['model_path'] = args.model if args.model else 'random_policy'
    
    with open(args.output, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n✓ Résultats sauvegardés: {args.output}")
    print("\n" + "="*70 + "\n")


if __name__ == "__main__":
    main()
