#!/usr/bin/env python
"""
Quick Start - Delivery Game Project
====================================
Script interactif pour démarrer facilement le projet.

Usage:
    python quick_start.py

Author: yasmi
"""

import os
import sys
from pathlib import Path
from datetime import datetime

# Ajoute le répertoire courant au path
sys.path.insert(0, str(Path(__file__).parent))

from utils import (
    create_directories,
    check_dependencies,
    print_system_info,
    set_random_seed
)


def print_header():
    """Affiche le header du menu"""
    print("\n" + "="*70)
    print("  DELIVERY GAME - Agent IA avec REINFORCE".center(70))
    print("="*70)
    print()


def print_menu():
    """Affiche le menu principal"""
    print("\n📋 OPTIONS:")
    print("-" * 70)
    print("  1. 🚀 Entraîner un nouvel agent")
    print("  2. 📊 Visualiser les résultats d'entraînement")
    print("  3. 🎮 Jouer au jeu (mode joueur ou IA)")
    print("  4. 📈 Évaluer un modèle entraîné")
    print("  5. ℹ️  Informations et configuration")
    print("  6. 🧹 Nettoyer les fichiers")
    print("  0. ❌ Quitter")
    print("-" * 70)


def menu_train():
    """Menu d'entraînement"""
    print("\n" + "="*70)
    print("ENTRAÎNEMENT D'UN AGENT")
    print("="*70)
    
    print("\n⚙️  Configuration:")
    print("-" * 70)
    
    # Paramètres personnalisés
    print("\nVoulez-vous utiliser les paramètres par défaut? (y/n)")
    custom = input("> ").strip().lower() != 'y'
    
    if custom:
        try:
            grid_size = int(input("Taille de la grille (défaut: 10): ") or "10")
            num_episodes = int(input("Nombre d'épisodes (défaut: 500): ") or "500")
            learning_rate = float(input("Taux d'apprentissage (défaut: 0.001): ") or "0.001")
            gamma = float(input("Gamma / actualisation (défaut: 0.99): ") or "0.99")
        except ValueError:
            print("⚠️  Valeurs invalides, utilisation des paramètres par défaut")
            grid_size = 10
            num_episodes = 500
            learning_rate = 0.001
            gamma = 0.99
    else:
        grid_size = 10
        num_episodes = 500
        learning_rate = 0.001
        gamma = 0.99
    
    print(f"\nParamètres:")
    print(f"  Grille: {grid_size}×{grid_size}")
    print(f"  Épisodes: {num_episodes}")
    print(f"  Learning rate: {learning_rate}")
    print(f"  Gamma: {gamma}")
    
    print("\n✓ Démarrage de l'entraînement...")
    print("-" * 70)
    
    # Import et entraînement
    from train_agent import REINFORCEAgent
    from game_env import DeliveryGameEnv
    
    set_random_seed(42)
    
    # Crée l'environnement
    env = DeliveryGameEnv(
        grid_size=grid_size,
        episode_length=150,
        num_obstacles=8
    )
    
    # Crée l'agent
    agent = REINFORCEAgent(
        state_size=env.state_size,
        action_size=env.action_size,
        learning_rate=learning_rate,
        gamma=gamma
    )
    
    # Entraîne
    agent.train(env, num_episodes=num_episodes, eval_interval=50)
    
    # Évalue
    eval_stats = agent.evaluate(env, num_episodes=100)
    
    # Sauvegarde
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_path = f"models/delivery_game_agent_{timestamp}.pt"
    stats_path = f"results/training_stats_{timestamp}.json"
    
    agent.save_model(model_path)
    agent.save_training_stats(stats_path)
    
    print(f"\n✓ Entraînement terminé!")
    print(f"  Modèle: {model_path}")
    print(f"  Stats: {stats_path}")
    
    return model_path, stats_path


def menu_visualize():
    """Menu de visualisation"""
    print("\n" + "="*70)
    print("VISUALISATION DES RÉSULTATS")
    print("="*70)
    
    # Liste les fichiers de statistiques disponibles
    results_dir = Path("results")
    stats_files = list(results_dir.glob("training_stats_*.json"))
    
    if not stats_files:
        print("\n⚠️  Aucun fichier de statistiques trouvé.")
        print("   Veuillez d'abord entraîner un agent.")
        return
    
    print("\n📁 Fichiers disponibles:")
    for i, f in enumerate(sorted(stats_files, reverse=True)[:5]):
        print(f"  {i+1}. {f.name}")
    
    print(f"\nEntrez le numéro du fichier (1-{len(stats_files)}) ou le chemin complet:")
    choice = input("> ").strip()
    
    try:
        idx = int(choice) - 1
        stats_file = sorted(stats_files, reverse=True)[idx]
    except (ValueError, IndexError):
        stats_file = Path(choice)
    
    if not stats_file.exists():
        print(f"⚠️  Fichier non trouvé: {stats_file}")
        return
    
    print(f"\nTraitement de {stats_file.name}...")
    
    from visualize_results import load_training_stats, print_training_summary, plot_training_results
    
    stats = load_training_stats(str(stats_file))
    print_training_summary(stats)
    
    output_path = f"results/plots_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
    plot_training_results(stats, save_path=output_path)
    
    print(f"✓ Graphiques sauvegardés: {output_path}")


def menu_play():
    """Menu de jeu"""
    print("\n" + "="*70)
    print("JOUER AU JEU")
    print("="*70)
    
    print("\n🎮 Mode de jeu:")
    print("-" * 70)
    print("  1. 👤 Joueur humain (vous contrôlez le robot)")
    print("  2. 🤖 Regarder l'IA jouer (agent entraîné)")
    print("  0. ↩️  Retour au menu")
    print("-" * 70)
    
    choice = input("\nChoisir un mode (0-2): ").strip()
    
    if choice == "1":
        print("\nLancement du jeu en mode joueur...")
        print("-" * 70)
        
        from play_game import play_as_human
        
        try:
            play_as_human()
        except KeyboardInterrupt:
            print("\n\n✓ Jeu fermé")
        except ImportError as e:
            print(f"\n⚠️  Erreur: pygame non installé")
            print(f"   Installez avec: pip install pygame")
    
    elif choice == "2":
        print("\n📁 Modèles disponibles:")
        
        models_dir = Path("models")
        model_files = list(models_dir.glob("*.pt"))
        
        if not model_files:
            print("⚠️  Aucun modèle trouvé.")
            print("   Veuillez d'abord entraîner un agent.")
            return
        
        for i, f in enumerate(sorted(model_files, reverse=True)):
            print(f"  {i+1}. {f.name}")
        
        print(f"\nEntrez le numéro du modèle (1-{len(model_files)}):")
        try:
            idx = int(input("> ").strip()) - 1
            model_path = sorted(model_files, reverse=True)[idx]
        except (ValueError, IndexError):
            print("⚠️  Choix invalide")
            return
        
        print(f"\nLancement du jeu avec le modèle...")
        print("-" * 70)
        
        from play_game import play_with_ai
        
        try:
            play_with_ai(str(model_path))
        except KeyboardInterrupt:
            print("\n\n✓ Jeu fermé")
        except ImportError:
            print(f"\n⚠️  Erreur: pygame non installé")


def menu_evaluate():
    """Menu d'évaluation"""
    print("\n" + "="*70)
    print("ÉVALUATION D'UN MODÈLE")
    print("="*70)
    
    # Liste les modèles disponibles
    models_dir = Path("models")
    model_files = list(models_dir.glob("*.pt"))
    
    if not model_files:
        print("\n⚠️  Aucun modèle trouvé.")
        return
    
    print("\n📁 Modèles disponibles:")
    for i, f in enumerate(sorted(model_files, reverse=True)[:10]):
        print(f"  {i+1}. {f.name}")
    
    print(f"\nChoisir un modèle (1-{min(len(model_files), 10)}):")
    try:
        idx = int(input("> ").strip()) - 1
        model_path = sorted(model_files, reverse=True)[idx]
    except (ValueError, IndexError):
        print("⚠️  Choix invalide")
        return
    
    print(f"\n⚙️  Options:")
    num_episodes = int(input("Nombre d'épisodes (défaut: 100): ") or "100")
    compare = input("Comparer avec politique aléatoire? (y/n): ").strip().lower() == 'y'
    
    print(f"\nÉvaluation de {model_path.name}...")
    print("-" * 70)
    
    import subprocess
    
    cmd = [
        "python", "evaluate_agent.py",
        "--model", str(model_path),
        "--episodes", str(num_episodes)
    ]
    
    if compare:
        cmd.append("--compare")
    
    subprocess.run(cmd)


def menu_info():
    """Menu d'informations"""
    print("\n" + "="*70)
    print("INFORMATIONS ET CONFIGURATION")
    print("="*70)
    
    print("\n📊 Informations système:")
    print_system_info()
    
    print("\n📁 État du projet:")
    
    # Compte les fichiers
    models = list(Path("models").glob("*.pt"))
    results = list(Path("results").glob("*.json")) + list(Path("results").glob("*.png"))
    
    print(f"  Modèles entraînés: {len(models)}")
    print(f"  Fichiers de résultats: {len(results)}")
    
    if models:
        print(f"\n  Modèles:")
        for m in sorted(models, reverse=True)[:5]:
            size_mb = m.stat().st_size / (1024*1024)
            print(f"    - {m.name} ({size_mb:.1f} MB)")
    
    print("\n📖 Fichiers du projet:")
    py_files = list(Path(".").glob("*.py"))
    for f in sorted(py_files):
        size_kb = f.stat().st_size / 1024
        print(f"  - {f.name} ({size_kb:.1f} KB)")


def menu_cleanup():
    """Menu de nettoyage"""
    print("\n" + "="*70)
    print("NETTOYAGE")
    print("="*70)
    
    print("\n⚠️  Attention: Cette action est irréversible!")
    print("\nQue voulez-vous nettoyer?")
    print("  1. Modèles entraînés")
    print("  2. Fichiers de résultats")
    print("  3. Tout")
    print("  0. Annuler")
    
    choice = input("\nChoisir (0-3): ").strip()
    
    if choice in ["1", "3"]:
        if input("Supprimer les modèles? (y/n): ").strip().lower() == 'y':
            for f in Path("models").glob("*.pt"):
                f.unlink()
                print(f"  ✓ Supprimé: {f.name}")
    
    if choice in ["2", "3"]:
        if input("Supprimer les résultats? (y/n): ").strip().lower() == 'y':
            for f in Path("results").glob("*"):
                f.unlink()
                print(f"  ✓ Supprimé: {f.name}")
    
    if choice != "0":
        print("\n✓ Nettoyage terminé")


def main():
    """Fonction principale"""
    
    # Initialisation
    print_header()
    
    # Vérifie les dépendances
    if not check_dependencies():
        print("\n⚠️  Certaines dépendances manquent. Continuez à vos risques.")
    
    # Crée les répertoires
    create_directories()
    
    # Boucle principale
    while True:
        print_menu()
        choice = input("Choisir une option (0-6): ").strip()
        
        if choice == "1":
            try:
                menu_train()
            except Exception as e:
                print(f"\n❌ Erreur: {e}")
        
        elif choice == "2":
            try:
                menu_visualize()
            except Exception as e:
                print(f"\n❌ Erreur: {e}")
        
        elif choice == "3":
            try:
                menu_play()
            except Exception as e:
                print(f"\n❌ Erreur: {e}")
        
        elif choice == "4":
            try:
                menu_evaluate()
            except Exception as e:
                print(f"\n❌ Erreur: {e}")
        
        elif choice == "5":
            try:
                menu_info()
            except Exception as e:
                print(f"\n❌ Erreur: {e}")
        
        elif choice == "6":
            try:
                menu_cleanup()
            except Exception as e:
                print(f"\n❌ Erreur: {e}")
        
        elif choice == "0":
            print("\n👋 Au revoir!\n")
            break
        
        else:
            print("⚠️  Option invalide")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Programme interrompu\n")
    except Exception as e:
        print(f"\n❌ Erreur fatale: {e}\n")
