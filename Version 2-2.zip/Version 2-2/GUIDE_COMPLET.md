# 📚 GUIDE COMPLET DU PROJET DELIVERY GAME

## 📋 Table des matières
1. [Structure générale](#structure-générale)
2. [Description des fichiers](#description-des-fichiers)
3. [Workflow complet](#workflow-complet)
4. [Commandes rapides](#commandes-rapides)
5. [Dépannage](#dépannage)

---

## Structure générale

```
delivery_game_project/
│
├── 🎮 FICHIERS DE JEU & ENVIRONNEMENT
│   ├── game_env.py              ← Environnement du jeu
│   └── policy_network.py        ← Réseau de politique IA
│
├── 🧠 FICHIERS D'ENTRAÎNEMENT
│   ├── train_agent.py           ← Entraînement REINFORCE
│   └── evaluate_agent.py        ← Évaluation du modèle
│
├── 🎯 FICHIERS DE VISUALISATION & JEU
│   ├── play_game.py             ← Interface Pygame
│   ├── visualize_results.py     ← Graphiques des résultats
│   └── quick_start.py           ← Menu interactif
│
├── 🛠️  UTILITAIRES
│   ├── utils.py                 ← Fonctions helper
│   └── requirements.txt          ← Dépendances
│
├── 📁 DOSSIERS
│   ├── models/                  ← Modèles entraînés (.pt)
│   ├── results/                 ← Résultats et statistiques
│   └── data/                    ← Données (optionnel)
│
└── 📖 DOCUMENTATION
    ├── README.md                ← Documentation principale
    └── GUIDE_COMPLET.md         ← Ce fichier
```

---

## Description des fichiers

### 🎮 FICHIERS DE JEU

#### `game_env.py` (400 lignes)
**Rôle:** Implémente l'environnement du jeu (logique, états, récompenses)

**Classes principales:**
- `Action(Enum)`: Actions possibles (UP, DOWN, LEFT, RIGHT, STAY)
- `DeliveryGameEnv`: Environnement gridworld complet

**Méthodes clés:**
```python
env = DeliveryGameEnv(grid_size=10, episode_length=150, num_obstacles=8)
state = env.reset()                    # Initialise un nouvel épisode
state, reward, done, info = env.step(action)  # Exécute une action
grid = env.get_grid_representation()   # Obtient la grille visuelle
```

**État retourné:** `[robot_x, robot_y, package_x, package_y, goal_x, goal_y, has_package]`

**Récompenses:**
```
+10   : Récupérer le colis
+100  : Livrer le colis (succès!)
-1    : Chaque step (efficacité)
-5    : Collision avec mur
```

#### `policy_network.py` (350 lignes)
**Rôle:** Définit le réseau de neurones pour la politique

**Classes principales:**
- `PolicyNetwork`: Architecture simple (2 couches cachées, 64 neurones)
- `PolicyNetworkDeep`: Architecture profonde (optionnelle, 4 couches)

**Architecture NetworkPolicy:**
```
Input (7) → FC(64) + ReLU → FC(64) + ReLU → Output softmax (5 actions)
```

**Méthodes clés:**
```python
policy = PolicyNetwork(state_size=7, action_size=5)
action, log_prob = policy.get_action(state, training=True)  # Entraînement
action, log_prob = policy.get_action(state, training=False) # Évaluation (greedy)
log_probs, probs = policy.evaluate(states, actions)  # Pour backprop
```

**Nombre de paramètres:** ~650 paramètres entraînables

---

### 🧠 FICHIERS D'ENTRAÎNEMENT

#### `train_agent.py` (550 lignes)
**Rôle:** Entraîne l'agent avec l'algorithme REINFORCE

**Classe principale:**
- `REINFORCEAgent`: Wrapper pour l'entraînement

**Algorithme REINFORCE implémenté:**
```
1. Jouer un épisode complet (collect trajectory)
2. Calculer retours actualisés: G_t = Σ_k γ^(k-t) * r_k
3. Normaliser les retours (réduction de variance)
4. Calculer loss: L = -Σ_t log π(a_t|s_t) * G_t
5. Backpropagation et mise à jour des poids
```

**Métodes principales:**
```python
agent = REINFORCEAgent(state_size=7, action_size=5, learning_rate=1e-3, gamma=0.99)
agent.train(env, num_episodes=500, eval_interval=50)  # Entraînement
stats = agent.evaluate(env, num_episodes=100)        # Évaluation
agent.save_model("path/to/model.pt")                 # Sauvegarde
```

**Sortie:**
```json
{
  "episode_rewards": [list of episode returns],
  "episode_lengths": [list of episode lengths],
  "moving_avg_reward": [smoothed rewards],
  "hyperparameters": {...}
}
```

#### `evaluate_agent.py` (400 lignes)
**Rôle:** Évalue les performances du modèle entraîné

**Classe principale:**
- `ModelEvaluator`: Évaluation avec métriques

**Métriques calculées:**
```
- Récompense moyenne, écart-type, min, max
- Taux de succès (% d'épisodes réussis)
- Taux efficace (% réussi en < 100 steps)
- Longueur moyenne des épisodes
- Test de robustesse (performance sur différents jeux)
```

**Utilisation:**
```bash
# Évaluation simple
python evaluate_agent.py --model models/agent.pt --episodes 100

# Avec comparaison vs aléatoire
python evaluate_agent.py --model models/agent.pt --compare

# Test de robustesse
python evaluate_agent.py --model models/agent.pt --robustness
```

---

### 🎯 FICHIERS DE VISUALISATION & JEU

#### `play_game.py` (450 lignes)
**Rôle:** Interface pygame pour jouer au jeu

**Classes principales:**
- `GameDisplay`: Rendu graphique avec Pygame
- `GameController`: Gestion du gameplay (humain ou IA)

**Fonctionnalités:**
- ✅ Mode joueur humain (contrôle au clavier)
- ✅ Mode spectateur IA (regarder l'agent jouer)
- ✅ Affichage de la grille, obstacles, robot, colis, objectif
- ✅ Informations en temps réel

**Contrôles joueur:**
```
Flèches/ZQSD  → Mouvement
SPACE         → Rester immobile
Q             → Quitter
```

**Utilisation:**
```bash
python play_game.py
# Puis choisir:
# 1 = Mode humain
# 2 = Mode IA
```

#### `visualize_results.py` (400 lignes)
**Rôle:** Crée les graphiques des résultats d'entraînement

**Graphiques générés:**
```
1. Récompense par épisode (scatter + moyenne mobile)
2. Moyenne mobile lissée (tendance d'apprentissage)
3. Longueur des épisodes
4. Distribution des récompenses (histogramme)
```

**Utilisation:**
```bash
python visualize_results.py results/training_stats_YYYYMMDD_HHMMSS.json --show
```

**Résultat:** Fichier PNG avec 4 subplots

#### `quick_start.py` (450 lignes)
**Rôle:** Menu interactif pour lancer toutes les fonctions

**Menu principal:**
```
1. 🚀 Entraîner un nouvel agent
2. 📊 Visualiser les résultats
3. 🎮 Jouer au jeu
4. 📈 Évaluer un modèle
5. ℹ️  Infos système
6. 🧹 Nettoyer les fichiers
0. ❌ Quitter
```

**Utilisation:**
```bash
python quick_start.py
# Interface interactive
```

---

### 🛠️ UTILITAIRES

#### `utils.py` (300 lignes)
**Rôle:** Fonctions helper et utilitaires

**Fonctions principales:**
```python
create_directories()              # Crée models/, results/
set_random_seed(42)              # Reproductibilité
get_device()                     # CPU ou GPU
check_dependencies()             # Vérifie les imports
print_system_info()              # Infos système
count_parameters(model)          # Compte les params
ExperimentTracker()              # Logging d'expériences
```

#### `requirements.txt`
**Dépendances du projet:**
```
numpy>=1.19.0
torch>=1.9.0
pygame>=2.0.0
matplotlib>=3.3.0
tqdm>=4.50.0
```

**Installation:**
```bash
pip install -r requirements.txt
```

---

## Workflow complet

### 1️⃣ Installation (5 min)

```bash
# Cloner ou télécharger les fichiers
cd delivery_game_project

# Installer les dépendances
pip install -r requirements.txt

# Vérifier l'installation
python utils.py
```

### 2️⃣ Entraînement (10-15 min)

```bash
# Option A: Menu interactif (facile)
python quick_start.py
# Sélectionner option 1

# Option B: Directement
python train_agent.py
```

**Sortie attendue:**
```
Entraînement: |████████████████████| 500/500 [10:32<00:00]
Ep 050 | Reward: -25.3 | Success:  0.0%
Ep 100 | Reward:  15.2 | Success: 10.0%
...
Ep 500 | Reward:  65.8 | Success: 85.0%

✓ Modèle sauvegardé: models/delivery_game_agent_20240115_143022.pt
✓ Stats sauvegardées: results/training_stats_20240115_143022.json
```

### 3️⃣ Visualisation (1 min)

```bash
# Voir les résultats
python visualize_results.py results/training_stats_20240115_143022.json --show
```

### 4️⃣ Jouer & Tester (5 min)

```bash
# Option A: Jouer vous-même
python play_game.py
# Choisir 1

# Option B: Regarder l'IA
python play_game.py
# Choisir 2
# Indiquer le chemin du modèle

# Option C: Menu interactif
python quick_start.py
# Sélectionner option 3
```

### 5️⃣ Évaluation (5 min)

```bash
python evaluate_agent.py \
  --model models/delivery_game_agent_20240115_143022.pt \
  --episodes 100 \
  --compare
```

---

## Commandes rapides

### Entraînement rapide
```bash
python train_agent.py
```

### Tester sur 10 épisodes (configuration par défaut)
```python
from game_env import DeliveryGameEnv
env = DeliveryGameEnv()
env.reset()
for _ in range(10):
    action = env.action_space.sample()  # Aléatoire
    state, reward, done, info = env.step(action)
    if done:
        break
```

### Charger un modèle entraîné
```python
import torch
from policy_network import PolicyNetwork

model = PolicyNetwork(state_size=7, action_size=5)
model.load_state_dict(torch.load("models/agent.pt"))
model.eval()

# Utiliser
state = env.reset()
action, log_prob = model.get_action(state, training=False)
```

### Comparer plusieurs modèles
```bash
python evaluate_agent.py --model models/agent1.pt --compare
python evaluate_agent.py --model models/agent2.pt --compare
# Comparer les résultats dans results/evaluation.json
```

---

## Dépannage

### ❌ "ModuleNotFoundError: No module named 'torch'"
```bash
pip install torch
```

### ❌ "pygame.error: No available video device"
```bash
# Sous WSL ou sans affichage graphique
# Utiliser headless mode (voir play_game.py)
```

### ❌ "CUDA out of memory"
```python
# Réduire la taille du réseau
from policy_network import PolicyNetwork
model = PolicyNetwork(state_size=7, action_size=5, hidden_size=32)
```

### ❌ L'agent n'apprend pas

**Vérifier:**
1. Les récompenses sont-elles correctes? (env.step())
2. Le learning rate est-il approprié? (1e-3 par défaut)
3. Y a-t-il assez d'épisodes? (500 minimum)

**Solutions:**
```python
# 1. Augmenter learning rate
agent = REINFORCEAgent(learning_rate=5e-3)

# 2. Réduire coût par step
# Dans game_env.py, line ~150: reward -= 0.5

# 3. Plus d'épisodes
agent.train(env, num_episodes=1000)
```

---

## 📊 Résultats attendus

### Après 500 épisodes

**Récompense:**
```
Sans apprentissage: ~-50 (aléatoire)
Avec apprentissage:  ~+60 (agent entraîné)
```

**Taux de succès:**
```
Initial:  0-10%
Final:   70-90%
```

**Longueur moyenne:**
```
Initial:  150 steps (aléatoire)
Final:    70-100 steps (agent efficace)
```

---

## 📝 Structure pour un rapport

**Section Implémentation:**
- Répertorier les fichiers et leurs rôles
- Expliquer le workflow
- Montrer les paramètres utilisés

**Section Résultats:**
- Inclure les graphiques de visualize_results.py
- Tableau des métriques d'évaluation
- Comparaison vs baseline aléatoire

**Section Annexes:**
- Code principal (copie de game_env.py, train_agent.py)
- Résultats d'évaluation (output d'evaluate_agent.py)

---

**Projet réalisé avec ❤️ pour l'apprentissage par renforcement**
