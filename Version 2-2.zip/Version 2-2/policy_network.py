"""
Réseau de Politique pour le Delivery Game
===========================================
Réseau de neurones simple qui apprend une politique stochastique π_θ(a|s)
Utilise softmax pour produire une distribution de probabilités sur les actions.

Architecture:
- Couche d'entrée: state_size
- Couches cachées: 64 neurones chacune avec ReLU
- Couche de sortie: action_size (softmax)

Author: yasmi
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class PolicyNetwork(nn.Module):
    """
    Réseau de politique pour l'apprentissage par renforcement.

    Entrée: État (vecteur)
    Sortie: Distribution de probabilités sur les actions
    """

    def __init__(self, state_size, action_size, hidden_size=64):
        """
        Initialise le réseau de politique.

        Args:
            state_size: Dimension de l'espace d'état
            action_size: Nombre d'actions possibles
            hidden_size: Nombre de neurones dans les couches cachées
        """
        super(PolicyNetwork, self).__init__()

        self.state_size = state_size
        self.action_size = action_size

        self.fc1 = nn.Linear(state_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, action_size)

        self._initialize_weights()

    def _initialize_weights(self):
        """Initialise les poids du réseau."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                nn.init.constant_(module.bias, 0.1)

    def forward(self, state):
        """
        Passe avant du réseau.

        Args:
            state: Tensor de taille (batch_size, state_size) ou (state_size,)

        Returns:
            action_probs: Probabilités sur les actions (softmax)
        """
        if not torch.is_tensor(state):
            state = torch.tensor(state, dtype=torch.float32)

        state = state.float()

        if state.dim() == 1:
            state = state.unsqueeze(0)

        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        logits = self.fc3(x)
        action_probs = F.softmax(logits, dim=-1)

        return action_probs

    def get_action(self, state, training=True):
        """
        Échantillonne une action selon la politique.

        Args:
            state: État courant (numpy array ou tensor)
            training: Si True, échantillonne ; si False, prend le greedy

        Returns:
            action: Action sélectionnée (int)
            log_prob: Log-probabilité de l'action (tensor)
        """
        if isinstance(state, np.ndarray):
            state = torch.tensor(state, dtype=torch.float32)
        elif not torch.is_tensor(state):
            state = torch.tensor(state, dtype=torch.float32)

        action_probs = self.forward(state).squeeze(0)
        action_dist = torch.distributions.Categorical(action_probs)

        if training:
            action = action_dist.sample()
        else:
            action = torch.argmax(action_probs)

        log_prob = action_dist.log_prob(action)

        return action.item(), log_prob

    def evaluate(self, states, actions):
        """
        Évalue les log-probabilités des actions données.
        Utilisé pour l'entraînement REINFORCE.

        Args:
            states: Batch d'états (tensor de taille (batch_size, state_size))
            actions: Batch d'actions (tensor de taille (batch_size,))

        Returns:
            log_probs: Log-probabilités des actions
            action_probs: Probabilités de toutes les actions
        """
        action_probs = self.forward(states)
        action_dist = torch.distributions.Categorical(action_probs)
        log_probs = action_dist.log_prob(actions)

        return log_probs, action_probs


class PolicyNetworkDeep(nn.Module):
    """
    Variante plus profonde du réseau de politique.

    Architecture:
    - 4 couches cachées de 128 neurones chacune
    - Dropout pour la régularisation
    """

    def __init__(self, state_size, action_size, hidden_size=128):
        """Initialise le réseau profond."""
        super(PolicyNetworkDeep, self).__init__()

        self.state_size = state_size
        self.action_size = action_size

        self.fc1 = nn.Linear(state_size, hidden_size)
        self.dropout1 = nn.Dropout(0.2)

        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.dropout2 = nn.Dropout(0.2)

        self.fc3 = nn.Linear(hidden_size, hidden_size)
        self.dropout3 = nn.Dropout(0.2)

        self.fc4 = nn.Linear(hidden_size, hidden_size)
        self.dropout4 = nn.Dropout(0.2)

        self.fc5 = nn.Linear(hidden_size, action_size)

        self._initialize_weights()

    def _initialize_weights(self):
        """Initialise les poids."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                nn.init.constant_(module.bias, 0.1)

    def forward(self, state):
        """Passe avant."""
        if not torch.is_tensor(state):
            state = torch.tensor(state, dtype=torch.float32)

        state = state.float()

        if state.dim() == 1:
            state = state.unsqueeze(0)

        x = F.relu(self.fc1(state))
        x = self.dropout1(x)

        x = F.relu(self.fc2(x))
        x = self.dropout2(x)

        x = F.relu(self.fc3(x))
        x = self.dropout3(x)

        x = F.relu(self.fc4(x))
        x = self.dropout4(x)

        logits = self.fc5(x)
        action_probs = F.softmax(logits, dim=-1)

        return action_probs

    def get_action(self, state, training=True):
        """Échantillonne une action."""
        if isinstance(state, np.ndarray):
            state = torch.tensor(state, dtype=torch.float32)
        elif not torch.is_tensor(state):
            state = torch.tensor(state, dtype=torch.float32)

        action_probs = self.forward(state).squeeze(0)
        action_dist = torch.distributions.Categorical(action_probs)

        if training:
            action = action_dist.sample()
        else:
            action = torch.argmax(action_probs)

        log_prob = action_dist.log_prob(action)

        return action.item(), log_prob

    def evaluate(self, states, actions):
        """Évalue les log-probs."""
        action_probs = self.forward(states)
        action_dist = torch.distributions.Categorical(action_probs)
        log_probs = action_dist.log_prob(actions)
        return log_probs, action_probs


if __name__ == "__main__":
    print("Test du réseau de politique")
    print("-" * 40)

    state_size = 7
    action_size = 5
    policy = PolicyNetwork(state_size, action_size)

    print("Réseau créé:")
    print(policy)

    state = torch.randn(state_size)
    print(f"\nÉtat: {state}")

    action_probs = policy(state)
    print(f"Probabilités des actions: {action_probs}")

    action, log_prob = policy.get_action(state)
    print(f"Action échantillonnée: {action}")
    print(f"Log-probabilité: {log_prob.item():.4f}")

    action_eval, log_prob_eval = policy.get_action(state, training=False)
    print(f"Action en mode eval: {action_eval}")
    print(f"Log-probabilité: {log_prob_eval.item():.4f}")