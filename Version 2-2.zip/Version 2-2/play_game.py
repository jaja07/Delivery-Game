"""
Interface Pygame pour le Delivery Game
========================================
Permet au joueur humain de contrôler le robot ou de regarder l'IA jouer.

Contrôles (mode humain):
  - Flèches ou ZQSD pour se déplacer
  - E pour prendre/laisser le colis
  - SPACE pour rester immobile
  - Q pour quitter

Author: yasmi
"""

import pygame
import numpy as np
import torch
import sys
from pathlib import Path

from game_env import DeliveryGameEnv, Action
from policy_network import PolicyNetwork


class GameDisplay:
    """Affiche le jeu avec pygame"""
    
    def __init__(self, env, cell_size=50, fps=10):
        """
        Initialise l'affichage pygame.
        
        Args:
            env: Environnement du jeu
            cell_size: Taille d'une cellule en pixels
            fps: Images par seconde
        """
        self.env = env
        self.cell_size = cell_size
        self.fps = fps
        
        # Dimensions de la fenêtre
        self.width = env.grid_size * cell_size + 200
        self.height = env.grid_size * cell_size + 100
        
        # Initialise pygame
        pygame.init()
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Delivery Game - REINFORCE Agent")
        
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 24)
        self.font_large = pygame.font.Font(None, 32)
        
        # Couleurs
        self.colors = {
            'background': (240, 240, 240),
            'grid': (200, 200, 200),
            'obstacle': (100, 100, 100),
            'package': (255, 165, 0),
            'goal': (0, 200, 0),
            'robot': (0, 100, 200),
            'robot_with_package': (200, 0, 100),
            'text': (0, 0, 0),
            'info_bg': (220, 220, 220)
        }
    
    def draw_grid(self):
        """Dessine la grille"""
        offset_x = 10
        offset_y = 10
        
        # Fond blanc
        pygame.draw.rect(self.screen, self.colors['background'],
                        (offset_x, offset_y,
                         self.env.grid_size * self.cell_size,
                         self.env.grid_size * self.cell_size))
        
        # Grille
        for i in range(self.env.grid_size + 1):
            # Lignes verticales
            pygame.draw.line(self.screen, self.colors['grid'],
                           (offset_x + i * self.cell_size, offset_y),
                           (offset_x + i * self.cell_size,
                            offset_y + self.env.grid_size * self.cell_size))
            
            # Lignes horizontales
            pygame.draw.line(self.screen, self.colors['grid'],
                           (offset_x, offset_y + i * self.cell_size),
                           (offset_x + self.env.grid_size * self.cell_size,
                            offset_y + i * self.cell_size))
    
    def draw_elements(self):
        """Dessine les éléments du jeu (obstacles, colis, objectif, robot)"""
        offset_x = 10
        offset_y = 10
        
        # Obstacles
        for obs_x, obs_y in self.env.obstacles:
            rect = pygame.Rect(
                offset_x + obs_y * self.cell_size + 2,
                offset_y + obs_x * self.cell_size + 2,
                self.cell_size - 4,
                self.cell_size - 4
            )
            pygame.draw.rect(self.screen, self.colors['obstacle'], rect)
        
        # Colis (si pas pris)
        if not self.env.has_package:
            pkg_x, pkg_y = self.env.package_pos
            rect = pygame.Rect(
                offset_x + pkg_y * self.cell_size + 8,
                offset_y + pkg_x * self.cell_size + 8,
                self.cell_size - 16,
                self.cell_size - 16
            )
            pygame.draw.rect(self.screen, self.colors['package'], rect)
        
        # Objectif
        goal_x, goal_y = self.env.goal_pos
        rect = pygame.Rect(
            offset_x + goal_y * self.cell_size + 10,
            offset_y + goal_x * self.cell_size + 10,
            self.cell_size - 20,
            self.cell_size - 20
        )
        pygame.draw.rect(self.screen, self.colors['goal'], rect)
        
        # Robot
        robot_x, robot_y = self.env.robot_pos
        color = self.colors['robot_with_package'] if self.env.has_package \
                else self.colors['robot']
        
        circle_center = (
            offset_x + robot_y * self.cell_size + self.cell_size // 2,
            offset_y + robot_x * self.cell_size + self.cell_size // 2
        )
        pygame.draw.circle(self.screen, color, circle_center, self.cell_size // 2 - 5)
    
    def draw_info(self):
        """Affiche les informations sur le côté"""
        info_x = self.env.grid_size * self.cell_size + 30
        info_y = 20
        
        # Fond pour les infos
        pygame.draw.rect(self.screen, self.colors['info_bg'],
                        (info_x - 10, 0, 200, self.height))
        
        # Texte d'information
        texts = [
            f"Step: {self.env.current_step}",
            f"Robot: ({self.env.robot_pos[0]}, {self.env.robot_pos[1]})",
            f"Package: ({self.env.package_pos[0]}, {self.env.package_pos[1]})",
            f"Goal: ({self.env.goal_pos[0]}, {self.env.goal_pos[1]})",
            f"Has Package: {self.env.has_package}",
            "",
            "Legend:",
            "■ = Obstacle",
            "□ = Package",
            "◇ = Goal",
            "● = Robot",
            "◐ = Robot + Package"
        ]
        
        for i, text in enumerate(texts):
            surface = self.font.render(text, True, self.colors['text'])
            self.screen.blit(surface, (info_x, info_y + i * 25))
    
    def render(self):
        """Dessine l'écran"""
        self.screen.fill(self.colors['background'])
        self.draw_grid()
        self.draw_elements()
        self.draw_info()
        pygame.display.flip()


class GameController:
    """Contrôle le jeu (humain ou IA)"""
    
    def __init__(self, env, display, policy=None):
        """
        Initialise le contrôleur.
        
        Args:
            env: Environnement du jeu
            display: Affichage pygame
            policy: Réseau de politique (None pour joueur humain)
        """
        self.env = env
        self.display = display
        self.policy = policy
        self.is_ai = policy is not None
        self.game_over = False
        self.episode_reward = 0
    
    def get_action_from_input(self):
        """Récupère l'action depuis l'input clavier"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None  # Quitter
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    return None  # Quitter
                
                # Mouvements
                if event.key in [pygame.K_UP, pygame.K_z]:
                    return Action.UP.value
                if event.key in [pygame.K_DOWN, pygame.K_s]:
                    return Action.DOWN.value
                if event.key in [pygame.K_LEFT, pygame.K_q]:
                    return Action.LEFT.value
                if event.key in [pygame.K_RIGHT, pygame.K_d]:
                    return Action.RIGHT.value
                if event.key == pygame.K_SPACE:
                    return Action.STAY.value
        
        return None  # Aucune action
    
    def get_action_from_ai(self, state):
        """Récupère l'action depuis l'IA"""
        action, _ = self.policy.get_action(state, training=False)
        return action
    
    def play_episode(self):
        """Joue un épisode complet"""
        state = self.env.reset()
        self.game_over = False
        self.episode_reward = 0
        
        while not self.game_over:
            # Affiche
            self.display.render()
            self.display.clock.tick(self.display.fps)
            
            # Récupère l'action
            if self.is_ai:
                action = self.get_action_from_ai(state)
            else:
                action = self.get_action_from_input()
                if action is None:
                    return False  # Quitter le jeu
            
            # Exécute l'action
            state, reward, done, info = self.env.step(action)
            self.episode_reward += reward
            
            # Affiche le résultat
            if done:
                self.game_over = True
                if info["success"]:
                    print(f"\n✓ Succès! Récompense totale: {self.episode_reward:.1f}")
                else:
                    print(f"\n✗ Épisode terminé. Récompense totale: {self.episode_reward:.1f}")
        
        return True  # Continuer le jeu


def play_as_human():
    """Lance le jeu en mode joueur humain"""
    print("\n" + "="*60)
    print("MODE JOUEUR HUMAIN")
    print("="*60)
    print("Contrôles:")
    print("  - Flèches ou ZQSD pour se déplacer")
    print("  - SPACE pour rester immobile")
    print("  - Q pour quitter")
    print("="*60 + "\n")
    
    env = DeliveryGameEnv(grid_size=10, episode_length=200, num_obstacles=8)
    display = GameDisplay(env, cell_size=50, fps=5)
    controller = GameController(env, display)
    
    while True:
        if not controller.play_episode():
            break
        
        print("\nAppuyez sur une touche pour rejouer ou Q pour quitter...")
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        return
                    else:
                        waiting = False
            display.clock.tick(10)
    
    pygame.quit()


def play_with_ai(model_path):
    """Lance le jeu en mode IA"""
    print("\n" + "="*60)
    print("MODE IA")
    print("="*60)
    print(f"Chargement du modèle: {model_path}")
    
    # Crée l'environnement
    env = DeliveryGameEnv(grid_size=10, episode_length=200, num_obstacles=8)
    
    # Charge le modèle
    policy = PolicyNetwork(env.state_size, env.action_size)
    policy.load_state_dict(torch.load(model_path, weights_only=True))
    policy.eval()
    
    print("Modèle chargé avec succès!")
    print("="*60 + "\n")
    
    display = GameDisplay(env, cell_size=50, fps=5)
    controller = GameController(env, display, policy=policy)
    
    num_episodes = 0
    successes = 0
    
    while True:
        num_episodes += 1
        print(f"\nÉpisode {num_episodes}...")
        
        if not controller.play_episode():
            break
        
        if controller.env.current_step < controller.env.episode_length:
            successes += 1
        
        print("Appuyez sur une touche pour continuer ou Q pour quitter...")
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    break
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        break
                    else:
                        waiting = False
            if not waiting:
                break
            display.clock.tick(10)
        
        if not waiting:
            break
    
    print(f"\n{successes}/{num_episodes} épisodes réussis")
    pygame.quit()


if __name__ == "__main__":
    print("\nDELIVERY GAME - Mode de jeu")
    print("-" * 40)
    print("Options:")
    print("1. Jouer en tant que humain")
    print("2. Regarder l'IA jouer (nécessite un modèle entraîné)")
    print("-" * 40)
    
    choice = input("\nChoisir une option (1 ou 2): ").strip()
    
    if choice == "1":
        play_as_human()
    elif choice == "2":
        model_path = input("Chemin du modèle: ").strip()
        if Path(model_path).exists():
            play_with_ai(model_path)
        else:
            print(f"Erreur: Le fichier {model_path} n'existe pas")
    else:
        print("Option invalide")
    
    print("\nMerci d'avoir joué!")
