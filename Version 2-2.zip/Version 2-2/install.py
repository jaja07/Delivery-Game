#!/usr/bin/env python
"""
Installation et vérification du projet
=========================================
Installe les dépendances et vérifie que tout fonctionne.

Usage:
    python install.py

Author: yasmi
"""

import sys
import subprocess
import os
from pathlib import Path


def print_header():
    """Affiche le header"""
    print("\n" + "="*70)
    print("  DELIVERY GAME - Installation et vérification".center(70))
    print("="*70 + "\n")


def check_python_version():
    """Vérifie la version de Python"""
    print("✓ Vérification de Python...")
    
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"  Python {version.major}.{version.minor}.{version.micro} ✓")
        return True
    else:
        print(f"  ❌ Python 3.8+ requis (vous avez {version.major}.{version.minor})")
        return False


def install_dependencies():
    """Installe les dépendances"""
    print("\n✓ Installation des dépendances...")
    
    requirements = [
        "numpy>=1.19.0",
        "torch>=1.9.0",
        "pygame>=2.0.0",
        "matplotlib>=3.3.0",
        "tqdm>=4.50.0"
    ]
    
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-q"
        ] + requirements)
        print("  Tous les packages installés ✓")
        return True
    except subprocess.CalledProcessError as e:
        print(f"  ❌ Erreur lors de l'installation: {e}")
        return False


def verify_imports():
    """Vérifie que tous les modules peuvent être importés"""
    print("\n✓ Vérification des imports...")
    
    modules = {
        "numpy": "NumPy",
        "torch": "PyTorch",
        "pygame": "Pygame",
        "matplotlib": "Matplotlib",
        "tqdm": "tqdm"
    }
    
    all_good = True
    for module_name, display_name in modules.items():
        try:
            __import__(module_name)
            print(f"  {display_name:15} ✓")
        except ImportError:
            print(f"  {display_name:15} ❌")
            all_good = False
    
    return all_good


def create_structure():
    """Crée la structure des répertoires"""
    print("\n✓ Création de la structure des répertoires...")
    
    directories = ["models", "results", "data"]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"  {directory}/ ✓")
    
    return True


def verify_project_files():
    """Vérifie que tous les fichiers du projet existent"""
    print("\n✓ Vérification des fichiers du projet...")
    
    required_files = [
        "game_env.py",
        "policy_network.py",
        "train_agent.py",
        "play_game.py",
        "evaluate_agent.py",
        "visualize_results.py",
        "utils.py",
        "quick_start.py",
        "configs.py",
        "example_minimal.py",
        "README.md",
        "GUIDE_COMPLET.md",
        "requirements.txt"
    ]
    
    missing = []
    for filename in required_files:
        if Path(filename).exists():
            print(f"  {filename:25} ✓")
        else:
            print(f"  {filename:25} ❌")
            missing.append(filename)
    
    return len(missing) == 0, missing


def run_minimal_test():
    """Lance le test minimal"""
    print("\n✓ Exécution du test minimal...")
    
    try:
        from game_env import DeliveryGameEnv
        from policy_network import PolicyNetwork
        
        # Teste l'environnement
        env = DeliveryGameEnv(grid_size=8, episode_length=50, num_obstacles=2)
        env.reset()
        
        # Teste le réseau
        policy = PolicyNetwork(env.state_size, env.action_size)
        action, _ = policy.get_action(env.reset(), training=False)
        
        print("  Test de l'environnement    ✓")
        print("  Test du réseau             ✓")
        return True
    except Exception as e:
        print(f"  ❌ Erreur: {e}")
        return False


def print_next_steps():
    """Affiche les prochaines étapes"""
    print("\n" + "="*70)
    print("PROCHAINES ÉTAPES")
    print("="*70 + "\n")
    
    print("1️⃣  Lire la documentation:")
    print("   - README.md          (vue d'ensemble)")
    print("   - GUIDE_COMPLET.md   (détails complets)")
    print()
    
    print("2️⃣  Lancer une configuration de test:")
    print("   python configs.py fast")
    print()
    
    print("3️⃣  Ou utiliser le menu interactif:")
    print("   python quick_start.py")
    print()
    
    print("4️⃣  Ou lancer directement l'entraînement:")
    print("   python train_agent.py")
    print()


def main():
    """Fonction principale"""
    
    print_header()
    
    all_passed = True
    
    # Vérifications
    if not check_python_version():
        return False
    
    if not install_dependencies():
        print("\n⚠️  Certains packages n'ont pu être installés automatiquement")
        response = input("Continuer quand même? (y/n): ").strip().lower()
        if response != 'y':
            return False
    
    if not verify_imports():
        print("\n❌ Certains modules ne peuvent pas être importés")
        print("   Veuillez installer les dépendances manuellement:")
        print("   pip install -r requirements.txt")
        response = input("Continuer quand même? (y/n): ").strip().lower()
        if response != 'y':
            return False
    
    if not create_structure():
        all_passed = False
    
    files_ok, missing = verify_project_files()
    if not files_ok:
        print(f"\n⚠️  Fichiers manquants: {missing}")
    
    if not run_minimal_test():
        print("\n⚠️  Le test minimal a échoué")
        response = input("Continuer quand même? (y/n): ").strip().lower()
        if response != 'y':
            return False
    
    # Résumé
    print("\n" + "="*70)
    if all_passed and files_ok:
        print("✅ INSTALLATION RÉUSSIE".center(70))
    else:
        print("⚠️  INSTALLATION AVEC AVERTISSEMENTS".center(70))
    print("="*70)
    
    print_next_steps()
    
    print("="*70)
    print("Besoin d'aide?")
    print("  - Consultez README.md")
    print("  - Consultez GUIDE_COMPLET.md")
    print("  - Lancez: python example_minimal.py")
    print("="*70 + "\n")
    
    return True


if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n❌ Installation annulée\n")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Erreur: {e}\n")
        sys.exit(1)
