"""
Environnement du Delivery Game
================================
Environnement gridworld où un agent doit:
1. Récupérer un colis dans une zone initiale (qui change)
2. Le livrer dans une zone objectif (fixe)

Author: yasmi
"""

import numpy as np
from enum import Enum
import random


class Action(Enum):
    """Actions possibles de l'agent"""
    UP = 0
    DOWN = 1
    LEFT = 2
    RIGHT = 3
    STAY = 4


class DeliveryGameEnv:
    """
    Environnement du Delivery Game.
    
    État: position du robot, position du colis, position de l'objectif, si le colis est pris
    Actions: UP, DOWN, LEFT, RIGHT, STAY
    Récompenses: 
        - +10 pour prendre le colis
        - +100 pour livrer le colis à l'objectif
        - -0.1 par pas (encourage l'efficacité)  # CHANGÉ
        - -1 pour collision avec un mur        # CHANGÉ
    """
    
    def __init__(self, grid_size=10, episode_length=200, num_obstacles=2):  # PLUS LONG + MOINS D'OBSTACLES
        """
        Initialise l'environnement.
        
        Args:
            grid_size: Taille de la grille (grid_size x grid_size)
            episode_length: Nombre de steps max par épisode
            num_obstacles: Nombre d'obstacles (murs) à générer
        """
        self.grid_size = grid_size
        self.episode_length = episode_length
        self.num_obstacles = num_obstacles
        
        self.robot_pos = np.array([0, 0], dtype=np.int32)
        self.package_pos = np.array([0, 0], dtype=np.int32)
        self.goal_pos = np.array([grid_size - 1, grid_size - 1], dtype=np.int32)
        self.has_package = False
        self.obstacles = set()
        self.current_step = 0
        self.history = []
        
        self.reset()
    
    def _generate_obstacles(self):
        """Génère les obstacles aléatoirement"""
        self.obstacles = set()
        
        attempts = 0
        while len(self.obstacles) < self.num_obstacles and attempts < 100:
            x = random.randint(0, self.grid_size - 1)
            y = random.randint(0, self.grid_size - 1)
            
            if (x, y) != tuple(self.robot_pos) and \
               (x, y) != tuple(self.package_pos) and \
               (x, y) != tuple(self.goal_pos):
                self.obstacles.add((x, y))
            
            attempts += 1
    
    def reset(self):
        """Réinitialise l'environnement pour un nouvel épisode."""
        self.robot_pos = np.array([0, 0], dtype=np.int32)
        
        # Colis plus proche pour faciliter l'apprentissage
        while True:
            self.package_pos = np.array([
                random.randint(1, 3),  # ZONE PLUS PROCHE
                random.randint(1, 3)
            ], dtype=np.int32)
            if not np.array_equal(self.robot_pos, self.package_pos):
                break
        
        self.goal_pos = np.array([self.grid_size - 1, self.grid_size - 1], dtype=np.int32)
        self.has_package = False
        self._generate_obstacles()
        self.current_step = 0
        self.history = []
        
        return self._get_state()
    
    def _get_state(self):
        """Retourne l'état courant sous forme de vecteur."""
        state = np.concatenate([
            self.robot_pos,
            self.package_pos,
            self.goal_pos,
            np.array([float(self.has_package)])
        ]).astype(np.float32)
        return state
    
    def _is_collision(self, new_pos):
        """Vérifie si la nouvelle position est un obstacle ou hors limites"""
        if new_pos[0] < 0 or new_pos[0] >= self.grid_size or \
           new_pos[1] < 0 or new_pos[1] >= self.grid_size:
            return True
        
        if tuple(new_pos) in self.obstacles:
            return True
        
        return False
    
    def step(self, action):
        """Exécute une action dans l'environnement."""
        reward = 0
        done = False
        info = {"success": False}
        
        action_enum = Action(action)
        new_pos = self.robot_pos.copy()
        
        if action_enum == Action.UP:
            new_pos[0] -= 1
        elif action_enum == Action.DOWN:
            new_pos[0] += 1
        elif action_enum == Action.LEFT:
            new_pos[1] -= 1
        elif action_enum == Action.RIGHT:
            new_pos[1] += 1
        elif action_enum == Action.STAY:
            pass
        
        # Collision
        if self._is_collision(new_pos):
            reward -= 1  # Pénalité réduite
        else:
            self.robot_pos = new_pos
        
        # Coût par step REDUIT
        reward -= 0.1  # Était -1, maintenant -0.1
        
        # Prendre le colis
        if not self.has_package and np.array_equal(self.robot_pos, self.package_pos):
            self.has_package = True
            reward += 10
        
        # Livrer le colis
        if self.has_package and np.array_equal(self.robot_pos, self.goal_pos):
            done = True
            reward += 100
            info["success"] = True
        
        self.current_step += 1
        if self.current_step >= self.episode_length:
            done = True
        
        self.history.append({
            "action": action,
            "reward": reward,
            "robot_pos": self.robot_pos.copy(),
            "has_package": self.has_package
        })
        
        return self._get_state(), reward, done, info
    
    @property
    def state_size(self):
        return 7
    
    @property
    def action_size(self):
        return 5


if __name__ == "__main__":
    env = DeliveryGameEnv(grid_size=10, episode_length=200, num_obstacles=2)
    
    print("Test rapide:")
    for episode in range(5):
        state = env.reset()
        total_reward = 0
        
        for step in range(50):
            action = np.random.randint(0, 5)
            state, reward, done, info = env.step(action)
            total_reward += reward
            
            if done:
                print(f"Ep {episode}: reward={total_reward:.1f}, success={info['success']}")
                break