"""
Exemple minimal - Test rapide du projet
=======================================
Script pour vérifier que tout fonctionne avec une configuration simple.

Exécution: python example_minimal.py
Durée: ~1 minute

Author: yasmi
"""

import numpy as np
import torch
from pathlib import Path

print("\n" + "="*70)
print("EXEMPLE MINIMAL - TEST DU PROJET")
print("="*70 + "\n")

# ========================================
# 1. TEST DE L'ENVIRONNEMENT
# ========================================
print("1️⃣  Test de l'environnement...")
print("-" * 70)

from game_env import DeliveryGameEnv

env = DeliveryGameEnv(grid_size=8, episode_length=100, num_obstacles=3)
state = env.reset()

print(f"✓ Environnement créé")
print(f"  Taille de grille: 8×8")
print(f"  Taille de l'état: {env.state_size}")
print(f"  Nombre d'actions: {env.action_size}")
print(f"  État initial: {state}\n")

# Test quelques steps
print("  Exécution de 5 steps aléatoires...")
for i in range(5):
    action = np.random.randint(0, env.action_size)
    state, reward, done, info = env.step(action)
    print(f"    Step {i+1}: action={action}, reward={reward:.1f}, done={done}")

print("✓ Environnement fonctionne correctement!\n")

# ========================================
# 2. TEST DU RÉSEAU DE POLITIQUE
# ========================================
print("2️⃣  Test du réseau de politique...")
print("-" * 70)

from policy_network import PolicyNetwork

policy = PolicyNetwork(state_size=env.state_size, action_size=env.action_size)
print(f"✓ Réseau créé")
print(f"  Architecture: {policy}\n")

# Test forward pass
test_state = torch.randn(env.state_size)
probs = policy(test_state)
print(f"  Probabilités d'actions: {probs.detach().numpy()}")
print(f"  Somme: {probs.sum().item():.4f} (devrait être ~1.0)\n")

# Test action sampling
action, log_prob = policy.get_action(env.reset(), training=True)
print(f"  Action échantillonnée: {action}")
print(f"  Log-probabilité: {log_prob:.4f}")
print(f"✓ Réseau fonctionne correctement!\n")

# ========================================
# 3. TEST DE L'AGENT REINFORCE
# ========================================
print("3️⃣  Test de l'agent REINFORCE...")
print("-" * 70)

from train_agent import REINFORCEAgent

agent = REINFORCEAgent(
    state_size=env.state_size,
    action_size=env.action_size,
    learning_rate=1e-3,
    gamma=0.99
)

print(f"✓ Agent créé\n")

# Entraînement mini (50 épisodes)
print("  Entraînement sur 50 épisodes...")

agent.train(env, num_episodes=50, eval_interval=25)

print(f"\n  Récompenses:")
print(f"    Premier épisode: {agent.episode_rewards[0]:.1f}")
print(f"    Dernier épisode: {agent.episode_rewards[-1]:.1f}")
print(f"    Moyenne: {np.mean(agent.episode_rewards):.1f}")
print(f"    Amélioration: {agent.episode_rewards[-1] - agent.episode_rewards[0]:+.1f}\n")

print(f"✓ Agent entraîné avec succès!\n")

# ========================================
# 4. TEST D'ÉVALUATION
# ========================================
print("4️⃣  Test d'évaluation...")
print("-" * 70)

stats = agent.evaluate(env, num_episodes=10)

print(f"\n  Résultats d'évaluation (10 épisodes):")
print(f"    Récompense moyenne: {stats['mean_reward']:.2f}")
print(f"    Taux de succès: {stats['success_rate']:.1f}%")
print(f"    Longueur moyenne: {stats['mean_length']:.1f} steps\n")

print(f"✓ Évaluation complète!\n")

# ========================================
# 5. TEST DE SAUVEGARDE
# ========================================
print("5️⃣  Test de sauvegarde/chargement...")
print("-" * 70)

Path("models").mkdir(exist_ok=True)
Path("results").mkdir(exist_ok=True)

model_path = "models/test_model.pt"
stats_path = "results/test_stats.json"

agent.save_model(model_path)
print(f"✓ Modèle sauvegardé: {model_path}")

agent.save_training_stats(stats_path)
print(f"✓ Statistiques sauvegardées: {stats_path}\n")

# Charger le modèle
agent2 = REINFORCEAgent(
    state_size=env.state_size,
    action_size=env.action_size
)
agent2.load_model(model_path)
print(f"✓ Modèle chargé avec succès!\n")

# ========================================
# 6. RÉSUMÉ
# ========================================
print("="*70)
print("✅ TOUS LES TESTS RÉUSSIS!")
print("="*70)

print("""
Prochaines étapes:

1. Entraîner un agent complet:
   python train_agent.py

2. Visualiser les résultats:
   python visualize_results.py results/training_stats_*.json --show

3. Jouer au jeu:
   python play_game.py

4. Utiliser le menu interactif:
   python quick_start.py

Pour plus d'informations:
   - Voir README.md
   - Voir GUIDE_COMPLET.md
""")

print("="*70 + "\n")
