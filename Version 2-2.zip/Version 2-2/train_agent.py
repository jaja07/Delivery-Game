# -*- coding: utf-8 -*-
"""
Script d'entraînement REINFORCE pour le Delivery Game
=======================================================
Entraîne la politique avec l'algorithme REINFORCE (Policy Gradient).

REINFORCE Update:
∇θ J(θ) ≈ Σ ∇θ log π_θ(a_t|s_t) * G_t

où G_t = Σ_k γ^(k-t) * r_k est le retour actualisé depuis le temps t.

Author: yasmi
"""

import os
import json
from datetime import datetime

import numpy as np
import torch
import torch.optim as optim
from tqdm import tqdm

from policy_network import PolicyNetwork
from game_env import DeliveryGameEnv


class REINFORCEAgent:
    def __init__(self, state_size, action_size, learning_rate=1e-3, gamma=0.99):
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.gamma = gamma

        self.policy = PolicyNetwork(state_size, action_size)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=learning_rate)

        self.episode_rewards = []
        self.episode_lengths = []
        self.moving_avg_reward = []

    def compute_returns(self, rewards):
        returns = []
        G = 0

        for r in reversed(rewards):
            G = r + self.gamma * G
            returns.insert(0, G)

        return returns

    def train_episode(self, env):
        state = env.reset()

        log_probs = []
        rewards = []

        done = False
        episode_reward = 0
        success = False

        while not done:
            action, log_prob = self.policy.get_action(state, training=True)
            next_state, reward, done, info = env.step(action)

            log_probs.append(log_prob)
            rewards.append(reward)

            episode_reward += reward
            state = next_state

            if info.get("success", False):
                success = True

        returns = self.compute_returns(rewards)
        returns = torch.tensor(returns, dtype=torch.float32)

        if len(returns) > 1:
            returns = (returns - returns.mean()) / (returns.std() + 1e-8)

        losses = []
        for log_prob, G in zip(log_probs, returns):
            losses.append(-log_prob * G)

        loss = torch.stack(losses).sum()

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), max_norm=1.0)
        self.optimizer.step()

        self.episode_rewards.append(episode_reward)
        self.episode_lengths.append(len(rewards))

        window_size = min(100, len(self.episode_rewards))
        moving_avg = np.mean(self.episode_rewards[-window_size:])
        self.moving_avg_reward.append(moving_avg)

        return episode_reward, len(rewards), success

    def train(self, env, num_episodes=500, eval_interval=50):
        print("\n" + "=" * 60)
        print("ENTRAINEMENT AVEC REINFORCE")
        print("=" * 60)
        print(f"Nombre d'episodes: {num_episodes}")
        print(f"Learning rate: {self.learning_rate}")
        print(f"Gamma: {self.gamma}")
        print("=" * 60 + "\n")

        success_count = 0
        pbar = tqdm(range(num_episodes), desc="Training")

        for episode in pbar:
            episode_reward, episode_length, success = self.train_episode(env)

            if success:
                success_count += 1

            if (episode + 1) % eval_interval == 0:
                avg_reward = np.mean(self.episode_rewards[-eval_interval:])
                success_rate = success_count / eval_interval * 100

                pbar.set_description(
                    f"Ep {episode + 1:3d} | "
                    f"Reward: {avg_reward:7.1f} | "
                    f"Success: {success_rate:5.1f}%"
                )

                success_count = 0

        print("\n" + "=" * 60)
        print("ENTRAINEMENT TERMINE")
        print("=" * 60 + "\n")

    def evaluate(self, env, num_episodes=100):
        print(f"\nEvaluation sur {num_episodes} episodes...")

        rewards = []
        lengths = []
        successes = 0

        for _ in tqdm(range(num_episodes), desc="Evaluation"):
            state = env.reset()
            episode_reward = 0
            done = False

            while not done:
                action, _ = self.policy.get_action(state, training=False)
                state, reward, done, info = env.step(action)
                episode_reward += reward

                if info.get("success", False):
                    successes += 1

            rewards.append(episode_reward)
            lengths.append(env.current_step)

        stats = {
            "mean_reward": np.mean(rewards),
            "std_reward": np.std(rewards),
            "max_reward": np.max(rewards),
            "min_reward": np.min(rewards),
            "success_rate": successes / num_episodes * 100,
            "mean_length": np.mean(lengths),
            "std_length": np.std(lengths),
        }

        print("\nResultats:")
        print(f"Reward moyen: {stats['mean_reward']:.2f} +/- {stats['std_reward']:.2f}")
        print(f"Success rate: {stats['success_rate']:.1f}%")

        return stats

    def save_model(self, filepath):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        torch.save(self.policy.state_dict(), filepath)
        print(f"Modele sauvegarde: {filepath}")

    def save_training_stats(self, filepath):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        stats = {
            "episode_rewards": self.episode_rewards,
            "episode_lengths": self.episode_lengths,
            "moving_avg_reward": self.moving_avg_reward,
            "hyperparameters": {
                "learning_rate": self.learning_rate,
                "gamma": self.gamma,
            },
            "timestamp": datetime.now().isoformat(),
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

        print(f"Stats sauvegardees: {filepath}")


def main():
    env = DeliveryGameEnv(grid_size=10, episode_length=150, num_obstacles=8)

    agent = REINFORCEAgent(
        state_size=env.state_size,
        action_size=env.action_size
    )

    agent.train(env, num_episodes=500)
    agent.evaluate(env, num_episodes=100)


if __name__ == "__main__":
    main()