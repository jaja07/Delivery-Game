# Delivery Game - Agent IA avec REINFORCE

## 📋 Vue d'ensemble

Ce projet implémente un **agent d'intelligence artificielle** qui apprend à jouer à un jeu de **livraison de colis** en utilisant l'algorithme **REINFORCE** (Policy Gradient).

### 🎮 Concept du jeu

L'agent contrôle un robot dans un **labyrinthe 2D** qui doit:
1. **Récupérer un colis** dans une zone de départ (qui change à chaque partie)
2. **Le livrer à la zone objectif** (coin fixe)
3. Éviter les obstacles et minimiser le nombre de steps

### 🧠 Algorithme d'apprentissage

**REINFORCE** est un algorithme simple de gradient de politique:

```
∇θ J(θ) ≈ Σ_t ∇θ log π_θ(a_t|s_t) * G_t
```

Où:
- `π_θ(a|s)` est la politique stochastique paramétrée par θ
- `G_t` est le retour actualisé (cumul des récompenses)
- L'agent apprend en augmentant les probabilités des actions qui mènent à des récompenses élevées

---

## 📁 Structure du projet

```
delivery_game_project/
├── game_env.py                  # Environnement du jeu
├── policy_network.py            # Réseau de politique (PyTorch)
├── train_agent.py               # Script d'entraînement REINFORCE
├── play_game.py                 # Interface pygame
├── evaluate_agent.py            # Évaluation du modèle
├── visualize_results.py         # Graphiques des résultats
├── utils.py                     # Fonctions utilitaires
├── models/                      # Dossier des modèles entraînés
├── results/                     # Dossier des résultats et statistiques
└── README.md                    # Cette documentation
```

---

## 🚀 Installation et configuration

### Prérequis

- Python 3.8+
- Pip

### Installation des dépendances

```bash
pip install numpy torch pygame matplotlib tqdm
```

### Vérification des installations

```bash
python utils.py
```

---

## 🎯 Guide d'utilisation

### 1️⃣ Entraîner l'agent

Lancer l'entraînement REINFORCE sur 500 épisodes:

```bash
python train_agent.py
```

**Ce que fait ce script:**
- Crée un environnement 10×10 avec obstacles
- Initialise un réseau de politique (64 neurones cachés)
- Entraîne l'agent pendant 500 épisodes
- Sauvegarde le modèle et les statistiques

**Paramètres modifiables:**

```python
# Dans train_agent.py, section main()
GRID_SIZE = 10              # Taille de la grille
NUM_EPISODES = 500          # Nombre d'épisodes d'entraînement
LEARNING_RATE = 1e-3        # Taux d'apprentissage
GAMMA = 0.99               # Facteur d'actualisation
EVAL_INTERVAL = 50          # Affichage tous les N épisodes
```

**Sortie attendue:**

```
============================================================
ENTRAÎNEMENT AVEC REINFORCE
============================================================
Nombre d'épisodes: 500
Taux d'apprentissage: 0.001
Facteur d'actualisation (gamma): 0.99
============================================================

Entraînement:   |████████████████████| 500/500 [05:30<00:00]
Ep 050 | Reward: -25.3 | Success: 0.0%
Ep 100 | Reward:  15.2 | Success: 10.0%
...
Ep 500 | Reward:  65.8 | Success: 85.0%

============================================================
ENTRAÎNEMENT TERMINÉ
============================================================

✓ Modèle sauvegardé: models/delivery_game_agent_20240115_143022.pt
✓ Statistiques sauvegardées: results/training_stats_20240115_143022.json
```

### 2️⃣ Visualiser les résultats

Après l'entraînement, créer les graphiques:

```bash
python visualize_results.py results/training_stats_20240115_143022.json --show
```

**Graphiques générés:**
1. **Récompense par épisode** - Montre la variance
2. **Moyenne mobile** - Tendance d'apprentissage
3. **Longueur des épisodes** - Efficacité
4. **Distribution des récompenses** - Statistiques finales

### 3️⃣ Jouer au jeu

#### Mode joueur humain

```bash
python play_game.py
# Choisir option 1
```

**Contrôles:**
- `Flèches` ou `ZQSD` - Se déplacer
- `SPACE` - Rester immobile
- `Q` - Quitter

#### Regarder l'IA jouer

```bash
python play_game.py
# Choisir option 2
# Entrer le chemin du modèle: models/delivery_game_agent_20240115_143022.pt
```

### 4️⃣ Évaluer le modèle

Évaluer la performance du modèle entraîné:

```bash
# Évaluation simple
python evaluate_agent.py --model models/delivery_game_agent_20240115_143022.pt --episodes 100

# Avec comparaison vs politique aléatoire
python evaluate_agent.py --model models/delivery_game_agent_20240115_143022.pt --compare

# Test de robustesse
python evaluate_agent.py --model models/delivery_game_agent_20240115_143022.pt --robustness
```

**Exemple de résultats:**

```
Récompense moyenne: 65.23 ± 18.45
Récompense min/max: -15.0 / 98.5
Taux de succès: 82.0%
Taux efficace (< 100 steps): 75.0%
Longueur moyenne: 87.3 ± 21.5 steps
```

---

## 📊 Comprendre les résultats

### Métriques d'entraînement

| Métrique | Explication |
|----------|-----------|
| **Reward** | Cumul des récompenses d'un épisode |
| **Success Rate** | Pourcentage d'épisodes où le colis est livré |
| **Episode Length** | Nombre de steps pour terminer |
| **Moving Average** | Moyenne lissée (fenêtre 100) |

### Interprétation du graphique de récompense

```
Sans apprentissage        Avec apprentissage
  -50 ████               +70 ████
       ▓▓▓░░                ████
       ░░░░░                ████
     → Aléatoire           → Croissant
```

**Bon signe:** Courbe croissante avec variance décroissante
**Mauvais signe:** Plateau ou récompenses négatives

### Architecture du réseau

```python
PolicyNetwork(
    input: 7-dim state vector
    hidden1: 64 ReLU neurons
    hidden2: 64 ReLU neurons
    output: 5 action probabilities (softmax)
    Total parameters: ~650
)
```

---

## 🔧 Configuration avancée

### Modifier la taille du réseau

```python
# Dans train_agent.py
agent = REINFORCEAgent(
    state_size=env.state_size,
    action_size=env.action_size,
    learning_rate=1e-3,
    gamma=0.99
)

# Utiliser PolicyNetworkDeep pour une architecture plus profonde
from policy_network import PolicyNetworkDeep
agent.policy = PolicyNetworkDeep(env.state_size, env.action_size, hidden_size=128)
```

### Ajuster les récompenses

```python
# Dans game_env.py, méthode step()
reward += 10    # Colis pris
reward += 100   # Colis livré
reward -= 1     # Coût par step
reward -= 5     # Collision
```

### Difficultés du jeu

```python
# Grille plus grande
env = DeliveryGameEnv(grid_size=15, ...)

# Plus d'obstacles
env = DeliveryGameEnv(num_obstacles=15, ...)

# Épisodes plus courts (plus difficile)
env = DeliveryGameEnv(episode_length=50, ...)
```

---

## 📈 Améliorations optionnelles

Voici des extensions possibles (comme mentionné dans le document original):

### 1. Baseline pour réduire la variance
```python
# Dans train_agent.py
loss -= log_prob * (G - baseline)  # Soustrait un baseline
```

### 2. Reward-to-go
```python
# Utilise que les récompenses futures, pas les passées
returns = compute_returns(rewards[t:])  # À partir du temps t
```

### 3. Ennemis dynamiques
```python
# Dans game_env.py
# Ajouter des obstacles qui se déplacent
self.enemies = [(x, y), ...]
```

### 4. Réseau plus profond
```python
from policy_network import PolicyNetworkDeep
# 4 couches cachées, dropout
```

---

## 🐛 Dépannage

### Problème: L'agent n'apprend pas (récompense reste négative)

**Solutions:**
```python
# 1. Augmenter le taux d'apprentissage
learning_rate = 5e-3  # Au lieu de 1e-3

# 2. Réduire le coût par step
reward -= 0.5  # Au lieu de -1

# 3. Récompense plus grande pour le succès
reward += 200  # Au lieu de +100

# 4. Plus d'épisodes d'entraînement
num_episodes = 1000  # Au lieu de 500
```

### Problème: Out of memory

**Solutions:**
```python
# 1. Réduire la taille du batch (ne s'applique pas ici, mais important à noter)
# 2. Réseau plus petit
agent.policy = PolicyNetwork(env.state_size, env.action_size, hidden_size=32)

# 3. Grille plus petite
env = DeliveryGameEnv(grid_size=8, ...)
```

### Problème: Pygame ne s'affiche pas

**Solutions:**
```bash
# Mettre à jour pygame
pip install --upgrade pygame

# Sur Linux
pip install pygame-ce  # Version community

# Vérifier l'installation
python -m pygame
```

---

## 📚 Ressources pédagogiques

### Concepts clés expliqués

**Politique stochastique π(a|s):**
- Mappe un état à une distribution de probabilités sur les actions
- Permet l'exploration (actions aléatoires)
- Apprend les bonnes actions

**Retour actualisé G_t:**
```
G_t = r_t + γ*r_{t+1} + γ²*r_{t+2} + ...
```
- γ proche de 0: court terme (myope)
- γ proche de 1: long terme (lointain)

**Gradient de politique:**
```
log π(a|s) = log P(a|s)  # Log-probabilité
∇θ log π(a|s)           # Direction pour augmenter P(a|s)
```

### Références

- **Sutton & Barto** - *Reinforcement Learning: An Introduction* (Ch. 13)
- **OpenAI** - Policy Gradient methods
- **DeepMind** - Policy Gradient tutorial

---

## 📝 Rapport attendu

Votre rapport doit contenir:

1. **Introduction**
   - Motivation
   - Objectifs du projet

2. **Concepts théoriques**
   - Explication de REINFORCE
   - Formules mathématiques
   - Avantages et limites

3. **Implémentation**
   - Architecture du réseau
   - Détails de l'entraînement
   - Hyperparamètres choisis

4. **Résultats**
   - Graphiques des courbes d'apprentissage
   - Tableau des performances
   - Comparaison vs baseline

5. **Analyse**
   - Interprétation des résultats
   - Comportement de l'agent
   - Améliorations possibles

6. **Conclusion**
   - Bilan
   - Leçons apprises

---

## 📞 Support

Pour toute question ou problème:

1. Vérifiez la section "Dépannage"
2. Consultez les commentaires dans le code
3. Testez avec des paramètres simples d'abord
4. Utilisez `--help` pour les scripts

---

## 📄 Licence et attribution

Projet éducatif - Delivery Game with REINFORCE
Basé sur les concepts de Sutton & Barto (Reinforcement Learning)

---

**Bon apprentissage ! 🚀**
