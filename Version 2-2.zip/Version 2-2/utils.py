"""
Utilitaires pour le Delivery Game
==================================
Fonctions Helper pour l'entraînement, l'évaluation et la visualisation.

Author: yasmi
"""

import numpy as np
import torch
from pathlib import Path
import subprocess
import os
import sys

def create_directories():
    """Crée les répertoires nécessaires"""
    directories = [
        'models',
        'results',
        'data'
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✓ Répertoire créé/vérifié: {directory}")


def set_random_seed(seed=42):
    """
    Définit les seeds aléatoires pour la reproductibilité.
    
    Args:
        seed: Seed à utiliser
    """
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    # Pour CUDA si disponible
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
    
    print(f"✓ Seeds définis: {seed}")


def get_device():
    """Retourne le device (CPU ou GPU)"""
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print(f"✓ GPU trouvé: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        print("✓ Pas de GPU, utilisation du CPU")
    
    return device


def count_parameters(model):
    """
    Compte le nombre de paramètres du modèle.
    
    Args:
        model: Modèle PyTorch
    
    Returns:
        Nombre total de paramètres
    """
    total = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total


def format_number(num, decimals=2):
    """Formate un nombre avec séparateurs"""
    return f"{num:,.{decimals}f}"


def print_system_info():
    """Affiche les informations système"""
    print("\n" + "="*60)
    print("INFORMATIONS SYSTÈME")
    print("="*60)
    
    print(f"\nPython version: {sys.version}")
    print(f"PyTorch version: {torch.__version__}")
    
    if torch.cuda.is_available():
        print(f"CUDA disponible: Oui")
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"Nombre de GPU: {torch.cuda.device_count()}")
    else:
        print(f"CUDA disponible: Non")
    
    print("\n" + "="*60 + "\n")


class ExperimentTracker:
    """
    Suiveur d'expériences pour enregistrer les résultats.
    """
    
    def __init__(self, experiment_name):
        """
        Initialise le suiveur.
        
        Args:
            experiment_name: Nom de l'expérience
        """
        self.experiment_name = experiment_name
        self.metrics = {}
    
    def log_scalar(self, name, value, step=None):
        """
        Enregistre une métrique scalaire.
        
        Args:
            name: Nom de la métrique
            value: Valeur
            step: Numéro du step (optionnel)
        """
        if name not in self.metrics:
            self.metrics[name] = []
        
        self.metrics[name].append({
            'step': step,
            'value': value
        })
    
    def log_dict(self, metrics_dict, step=None):
        """Enregistre un dictionnaire de métriques"""
        for name, value in metrics_dict.items():
            self.log_scalar(name, value, step)
    
    def get_metric(self, name):
        """Récupère une métrique"""
        if name in self.metrics:
            return self.metrics[name]
        return None


def grid_search_hyperparameters(base_params, param_grid, num_trials=5):
    """
    Génère une grille de configurations pour chercher les meilleurs hyperparamètres.
    
    Args:
        base_params: Dictionnaire de base des paramètres
        param_grid: Grille des paramètres à tester
        num_trials: Nombre d'essais par configuration
    
    Returns:
        Liste des configurations
    """
    from itertools import product
    
    configs = []
    
    # Récupère les clés et valeurs des paramètres
    param_names = list(param_grid.keys())
    param_values = [param_grid[name] for name in param_names]
    
    # Génère toutes les combinaisons
    for values in product(*param_values):
        config = base_params.copy()
        for name, value in zip(param_names, values):
            config[name] = value
        
        configs.append(config)
    
    print(f"✓ Grille générée: {len(configs)} configurations")
    
    return configs


def check_dependencies():
    """Vérifie que toutes les dépendances sont installées"""
    dependencies = {
        'numpy': 'numpy',
        'torch': 'pytorch',
        'pygame': 'pygame',
        'matplotlib': 'matplotlib',
        'tqdm': 'tqdm'
    }
    
    print("\nVérification des dépendances...")
    print("-" * 40)
    
    missing = []
    
    for module, name in dependencies.items():
        try:
            __import__(module)
            print(f"✓ {name}")
        except ImportError:
            print(f"✗ {name} manquant")
            missing.append(name)
    
    if missing:
        print("\nDépendances manquantes. Installation recommandée:")
        print(f"pip install {' '.join(missing)}")
        return False
    
    print("-" * 40)
    print("✓ Toutes les dépendances sont installées\n")
    return True


def plot_learning_curve(rewards, window=100, title="Learning Curve"):
    """
    Crée une courbe d'apprentissage simple.
    
    Args:
        rewards: Liste des récompenses
        window: Fenêtre de lissage
        title: Titre du graphique
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib non disponible")
        return
    
    fig, ax = plt.subplots(figsize=(12, 5))
    
    episodes = np.arange(len(rewards))
    
    # Plot brut
    ax.scatter(episodes, rewards, alpha=0.2, s=5, color='blue', label='Récompense brute')
    
    # Moyenne mobile
    if len(rewards) > window:
        ma = np.convolve(rewards, np.ones(window)/window, mode='valid')
        ax.plot(range(window-1, len(episodes)), ma, color='red', linewidth=2, label=f'Moyenne mobile ({window})')
    
    ax.set_xlabel('Épisode')
    ax.set_ylabel('Récompense')
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    return fig, ax


if __name__ == "__main__":
    print("\nInitialisation du projet Delivery Game...")
    print("="*60)
    
    check_dependencies()
    create_directories()
    print_system_info()
    
    print("✓ Projet prêt pour l'entraînement!")
