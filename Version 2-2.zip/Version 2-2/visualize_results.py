"""
Visualisation des résultats d'entraînement
===========================================
Crée des graphiques des courbes d'apprentissage.

Plots générés:
1. Récompense par épisode
2. Moyenne mobile de la récompense
3. Longueur des épisodes
4. Taux de succès

Author: yasmi
"""

import json
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import sys


def load_training_stats(filepath):
    """
    Charge les statistiques d'entraînement depuis un fichier JSON.
    
    Args:
        filepath: Chemin du fichier JSON
    
    Returns:
        stats: Dictionnaire avec les statistiques
    """
    with open(filepath, 'r') as f:
        stats = json.load(f)
    
    return stats


def plot_training_results(stats, save_path="results/training_plots.png"):
    """
    Crée des graphiques pour visualiser l'entraînement.
    
    Args:
        stats: Dictionnaire des statistiques
        save_path: Chemin pour sauvegarder la figure
    """
    episode_rewards = stats['episode_rewards']
    episode_lengths = stats['episode_lengths']
    moving_avg_reward = stats['moving_avg_reward']
    
    # Crée une figure avec 2x2 subplots
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Résultats d\'entraînement REINFORCE - Delivery Game', 
                 fontsize=16, fontweight='bold')
    
    # ============================================
    # 1. Récompense par épisode
    # ============================================
    ax = axes[0, 0]
    episodes = np.arange(len(episode_rewards))
    ax.scatter(episodes, episode_rewards, alpha=0.3, s=10, color='blue', label='Récompense par épisode')
    ax.set_xlabel('Épisode', fontsize=11)
    ax.set_ylabel('Récompense', fontsize=11)
    ax.set_title('Récompense par épisode', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.legend()
    
    # ============================================
    # 2. Moyenne mobile (smoothing)
    # ============================================
    ax = axes[0, 1]
    ax.plot(episodes, moving_avg_reward, color='green', linewidth=2.5, label='Moyenne mobile (100)')
    ax.fill_between(episodes, moving_avg_reward, alpha=0.3, color='green')
    ax.set_xlabel('Épisode', fontsize=11)
    ax.set_ylabel('Récompense moyenne', fontsize=11)
    ax.set_title('Moyenne mobile de la récompense', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.legend()
    
    # ============================================
    # 3. Longueur des épisodes
    # ============================================
    ax = axes[1, 0]
    ax.scatter(episodes, episode_lengths, alpha=0.3, s=10, color='orange')
    ax.set_xlabel('Épisode', fontsize=11)
    ax.set_ylabel('Longueur (steps)', fontsize=11)
    ax.set_title('Longueur des épisodes', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Ajoute une moyenne mobile
    window = min(50, len(episode_lengths))
    if window > 1:
        ma = np.convolve(episode_lengths, np.ones(window)/window, mode='valid')
        ax.plot(range(window-1, len(episodes)), ma, color='red', linewidth=2, label='Moyenne mobile')
        ax.legend()
    
    # ============================================
    # 4. Distribution des récompenses
    # ============================================
    ax = axes[1, 1]
    ax.hist(episode_rewards, bins=30, color='purple', alpha=0.7, edgecolor='black')
    ax.set_xlabel('Récompense', fontsize=11)
    ax.set_ylabel('Fréquence', fontsize=11)
    ax.set_title('Distribution des récompenses', fontsize=12, fontweight='bold')
    ax.axvline(np.mean(episode_rewards), color='red', linestyle='--', 
               linewidth=2, label=f'Moyenne: {np.mean(episode_rewards):.1f}')
    ax.axvline(np.median(episode_rewards), color='green', linestyle='--',
               linewidth=2, label=f'Médiane: {np.median(episode_rewards):.1f}')
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    
    # Sauvegarde
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"\nGraphiques sauvegardés: {save_path}")
    
    return fig


def print_training_summary(stats):
    """Affiche un résumé des statistiques d'entraînement"""
    
    episode_rewards = np.array(stats['episode_rewards'])
    episode_lengths = np.array(stats['episode_lengths'])
    hyperparams = stats['hyperparameters']
    
    print("\n" + "="*60)
    print("RÉSUMÉ DE L'ENTRAÎNEMENT")
    print("="*60)
    
    print("\nHyperpapramètres:")
    print(f"  Learning rate: {hyperparams['learning_rate']}")
    print(f"  Gamma (facteur d'actualisation): {hyperparams['gamma']}")
    print(f"  State size: {hyperparams['state_size']}")
    print(f"  Action size: {hyperparams['action_size']}")
    
    print("\nStatistiques de récompense:")
    print(f"  Récompense moyenne: {np.mean(episode_rewards):.2f}")
    print(f"  Récompense médiane: {np.median(episode_rewards):.2f}")
    print(f"  Écart-type: {np.std(episode_rewards):.2f}")
    print(f"  Min / Max: {np.min(episode_rewards):.1f} / {np.max(episode_rewards):.1f}")
    
    # Calcule le taux de succès (récompense finale > 50 par exemple)
    success_threshold = 50
    success_rate = np.sum(episode_rewards > success_threshold) / len(episode_rewards) * 100
    print(f"  Taux de "succès" (récompense > {success_threshold}): {success_rate:.1f}%")
    
    print("\nStatistiques de longueur:")
    print(f"  Longueur moyenne: {np.mean(episode_lengths):.1f}")
    print(f"  Longueur médiane: {np.median(episode_lengths):.1f}")
    print(f"  Min / Max: {np.min(episode_lengths)} / {np.max(episode_lengths)}")
    
    # Tendance (premier vs dernier 100 épisodes)
    if len(episode_rewards) >= 200:
        first_100_mean = np.mean(episode_rewards[:100])
        last_100_mean = np.mean(episode_rewards[-100:])
        improvement = ((last_100_mean - first_100_mean) / abs(first_100_mean)) * 100
        
        print("\nTendance d'apprentissage:")
        print(f"  Moyenne 1-100: {first_100_mean:.2f}")
        print(f"  Moyenne derniers 100: {last_100_mean:.2f}")
        print(f"  Amélioration: {improvement:+.1f}%")
    
    print("\n" + "="*60 + "\n")


def plot_comparison(stats_list, labels, save_path="results/comparison_plots.png"):
    """
    Compare plusieurs courbes d'entraînement.
    
    Args:
        stats_list: Liste des statistiques (dicts)
        labels: Noms des modèles
        save_path: Chemin pour sauvegarder
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle('Comparaison de plusieurs entraînements', fontsize=14, fontweight='bold')
    
    colors = plt.cm.Set1(np.linspace(0, 1, len(stats_list)))
    
    # Première courbe: Récompense brute
    ax = axes[0]
    for stats, label, color in zip(stats_list, labels, colors):
        rewards = stats['episode_rewards']
        episodes = np.arange(len(rewards))
        ax.scatter(episodes, rewards, alpha=0.2, s=5, color=color)
        
        # Moyenne mobile
        window = min(50, len(rewards))
        if window > 1:
            ma = np.convolve(rewards, np.ones(window)/window, mode='valid')
            ax.plot(range(window-1, len(episodes)), ma, color=color, linewidth=2.5, label=label)
    
    ax.set_xlabel('Épisode', fontsize=11)
    ax.set_ylabel('Récompense', fontsize=11)
    ax.set_title('Récompense par épisode (moyenne mobile)', fontsize=12, fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Deuxième courbe: Distribution finale
    ax = axes[1]
    positions = np.arange(len(stats_list))
    
    for i, (stats, label, color) in enumerate(zip(stats_list, labels, colors)):
        rewards = stats['episode_rewards'][-100:]  # Derniers 100 épisodes
        mean_reward = np.mean(rewards)
        std_reward = np.std(rewards)
        
        ax.bar(i, mean_reward, yerr=std_reward, capsize=5, 
               color=color, alpha=0.7, edgecolor='black', linewidth=1.5)
    
    ax.set_ylabel('Récompense moyenne (derniers 100)', fontsize=11)
    ax.set_title('Performance finale', fontsize=12, fontweight='bold')
    ax.set_xticks(positions)
    ax.set_xticklabels(labels, rotation=15)
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"Graphique de comparaison sauvegardé: {save_path}")
    
    return fig


def main():
    """Fonction principale"""
    
    import argparse
    
    parser = argparse.ArgumentParser(description='Visualise les résultats d\'entraînement')
    parser.add_argument('stats_file', help='Fichier JSON avec les statistiques')
    parser.add_argument('--output', default='results/training_plots.png',
                       help='Chemin pour sauvegarder les graphiques')
    parser.add_argument('--show', action='store_true', help='Affiche les graphiques')
    
    args = parser.parse_args()
    
    # Charge et affiche les statistiques
    print(f"Chargement des statistiques: {args.stats_file}")
    stats = load_training_stats(args.stats_file)
    
    print_training_summary(stats)
    plot_training_results(stats, save_path=args.output)
    
    if args.show:
        plt.show()


if __name__ == "__main__":
    # Exemple d'utilisation si aucun argument
    if len(sys.argv) == 1:
        print("\nDELIVERY GAME - Visualisation des résultats")
        print("-" * 50)
        print("Usage: python visualize_results.py <stats_file> [--output path] [--show]")
        print("\nExemple:")
        print("  python visualize_results.py results/training_stats_20240101_120000.json --show")
    else:
        main()
